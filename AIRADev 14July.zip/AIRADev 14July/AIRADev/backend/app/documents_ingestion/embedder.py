from config.config_loader import ConfigLoader
from rag_pipeline.embeddings.ollama_embed import OllamaEmbedder
from rag_pipeline.embeddings.openai_embed import OpenAIEmbedder
from rag_pipeline.embeddings.azure_openai_embed import AzureOpenAIEmbedder

def get_embedder(config) -> object:
    
    backend = config.get("embeddings", "backend", default="ollama").lower()

    if backend == "openai":
        return OpenAIEmbedder(
            model=config.get("embeddings", "openai", "model"),
            api_key=config.get("embeddings", "openai", "api_key"),
            base_url=config.get("embeddings", "openai", "base_url")
        )
    elif backend == "azure":
        return AzureOpenAIEmbedder(
            model=config.get("embeddings", "azure", "deployment_name"),
            base_url=config.get("embeddings", "azure", "base_url"),
            api_key=config.get("embeddings", "azure", "api_key"),
            deployment_name=config.get("embeddings", "azure", "deployment_name"),
            model_version=config.get("embeddings", "azure", "model_version"),
            api_type=config.get("embeddings", "azure", "api_type")
        )
    else:
        return OllamaEmbedder(
            model=config.get("embeddings", "ollama", "model"),
            base_url=config.get("embeddings", "ollama", "base_url")
        )

def embed_chunks_with_dynamic_backend(chunks, config):

    embedder = get_embedder(config)

    if hasattr(embedder, "embed_section_chunks"):
        return embedder.embed_section_chunks(chunks)

    # Fallback to individual embedding
    embeddings, valid_chunks = [], []
    for chunk in chunks:
        text = chunk.get("content", "")
        if not text.strip():
            continue
        embedding = embedder.embed(text)
        if embedding:
            embeddings.append(embedding)
            valid_chunks.append(chunk)
    return embeddings, valid_chunks


