import psycopg2

# Database connection parameters
conn = psycopg2.connect(
    host="your_host",
    database="your_database",
    user="your_username",
    password="your_password"
)

# Create a cursor object
cur = conn.cursor()

try:
    # Truncate the table
    cur.execute("TRUNCATE TABLE your_table_name RESTART IDENTITY CASCADE;")
    conn.commit()
    print("Table truncated successfully.")
except Exception as e:
    print(f"Error: {e}")
    conn.rollback()
finally:
    # Close the cursor and connection
    cur.close()
    conn.close()
