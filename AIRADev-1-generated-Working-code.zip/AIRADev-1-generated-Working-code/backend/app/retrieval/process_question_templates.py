import ast
import logging
import json

# ----------------------------------------
# Helper: handle "group" type questions
# ----------------------------------------
def parse_value(value, context):
    """Safely parses and validates the 'Row' value."""
    if value is not None and str(value).strip() != "":
        try:
            parsed_value = int(value)
            logging.info(f"{context} parsed: {parsed_value}")
            return parsed_value
        except ValueError:
            logging.warning(f"Invalid '{context}' value: {value}. Defaulting to None.")
    else:
        logging.warning(f"'{context}' is empty or None. Defaulting to None.")
    return None



def handle_group_questions(q_template, q_type, product_code, form_dict_input_fn, query_llama_fn, config):
    #logging.info("inside group function")
    document_id = q_template["DocumentID"]
    dictionary_element = q_template["Dictionary_Element"]
    repeat = q_template.get("Repeat", False)
    
    column = parse_value(q_template.get("Column"), context="Column")
    row = parse_value(q_template.get("Row"), context="Row")

    group_responses = []
    for sub_q in q_template["Group"]:
        question_text = sub_q["Question"].format(document_id=document_id, product_code=product_code)
        logging.info(f"group question: {question_text}")
        prompt_template = sub_q["Prompt_Template"]
        full_document_search = sub_q.get("FullText", False)
        where_filter = sub_q.get("Where_Filter")
        max_results = int(sub_q.get("max_results", q_template.get("max_results", config["max_results"])))
        where_document = sub_q.get("Where_Document")
        logging.info(f"group where_filter: {where_filter}")
        response = query_llama_fn(
            question_text,
            document_id,
            prompt_template,
            full_document_search,
            where_filter,
            where_document,
            max_results,
            config
        )
        if response:
            group_responses.append(str(response).strip())

    combined_response = ", ".join(group_responses)
    form_dict_input_fn(dictionary_element, combined_response, column, row, repeat, q_type)


# ----------------------------------------
# Helper: handle "single" type questions
# ----------------------------------------
def handle_single_question(q_template, q_type, product_code, form_dict_input_fn, query_llama_fn, config):
    document_id = q_template["DocumentID"]
    logging.info(f"DocumentID: {document_id}")
    dictionary_element = q_template["Dictionary_Element"]
    column = parse_value(q_template.get("Column"), context="Column")
    row = parse_value(q_template.get("Row"), context="Row")
    repeat = q_template.get("Repeat", False)
    question_text = q_template["Question"].format(document_id=document_id, product_code=product_code)
    logging.info(f"question_text: {question_text}")
    prompt_template = q_template["Prompt_Template"]
    full_document_search = q_template.get("FullText", False)
    where_filter = q_template.get("Where_Filter")
    max_results = int(q_template.get("max_results", config["max_results"]))
    where_document = q_template.get("Where_Document")

    response = query_llama_fn(
        question_text,
        document_id,
        prompt_template,
        full_document_search,
        where_filter,
        where_document,
        max_results,
        config
    )

    if not response:
        return

    if isinstance(response, str):
        try:
            parsed = ast.literal_eval(response.strip())
            response = parsed
        except Exception:
            response = response.strip()

    form_dict_input_fn(dictionary_element, response, column, row, repeat, q_type)


# ----------------------------------------
# Main: supports single, group, and link
# ----------------------------------------
def process_question_templates(questions_fn, product_code, form_dict_input_fn, query_llama_fn, dict_data, config):
    try:
        # question_templates = questions_fn()

        question_templates = questions_fn(
            config,
            master_table='Master Input JSON Table',
            group_table='Group Table',
            link_table='Link Table'
        )
        
        # If the templates are returned as a string, parse it to JSON
        if isinstance(question_templates, str):
            try:
                question_templates = json.loads(question_templates)  # Parse the JSON string into a Python dict
            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse question templates: {e}")
                return

        logging.info(f"Question templates: {json.dumps(question_templates, indent=2)}")
        
        # Check if 'Questions' exists and is a list
        if not isinstance(question_templates, dict) or "Questions" not in question_templates or not isinstance(question_templates["Questions"], list):
            logging.error(f"Invalid question templates format: {json.dumps(question_templates, indent=2)}")
            return

        for q_template in question_templates["Questions"]:
            # Ensure that q_template is a dictionary
            if not isinstance(q_template, dict):
                logging.error(f"Invalid question template (not a dictionary): {q_template}")
                continue
       
            q_type = q_template.get("Type", "Single")
            logging.info(f"questions: {q_type}")
            if q_type == "Group":
                handle_group_questions(q_template, q_type, product_code, form_dict_input_fn, query_llama_fn, config)

            elif q_type == "Link":
                # 1. Ask the root-level link question
                
                question = q_template.get("Question")
                if question and question != "N/A":
                    handle_single_question(q_template, q_type, product_code, form_dict_input_fn, query_llama_fn, config)


                # 2. Process each linked sub-question
                for link_sub_q in q_template.get("Link", []):
                    sub_type = link_sub_q.get("Type", "single")
                    
                    row_from_master = parse_value(q_template.get("Row"), context="Row")

                    # Set it on the link sub-question if not already set
                    if "Row" not in link_sub_q or link_sub_q["Row"] in [None, "", "null"]:
                        link_sub_q["Row"] = row_from_master
                        #logging.info(f"row value set: {link_sub_q['Row']}")

                    #logging.info(f"row value from master table: {row_from_master}")
                    
                    if sub_type == "Group":
                        handle_group_questions(link_sub_q, sub_type, product_code, form_dict_input_fn, query_llama_fn, config)
                    else:
                        handle_single_question(link_sub_q, sub_type, product_code, form_dict_input_fn, query_llama_fn, config)

            else:
                handle_single_question(q_template, q_type, product_code, form_dict_input_fn, query_llama_fn, config)

    except Exception as e:
        logging.info(f"Error while processing question templates: {e}")

    logging.info(f"dict data: {json.dumps(dict_data, indent=2)}")
