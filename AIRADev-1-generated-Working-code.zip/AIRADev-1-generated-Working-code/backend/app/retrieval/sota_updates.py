import pandas as pd
import re
from collections import defaultdict
from .standard_normalization import extract_standard_number

def read_standards_from_sota_excel(file_path, sheet_name=0):
    df = pd.read_excel(file_path, sheet_name=sheet_name)
    # Column 3 means index 2 (0-based indexing)
    standards = df.iloc[:, 2].dropna().astype(str).tolist()
    return standards

def update_sota_field(merged_output, sota_dict):
    # Step 1: Build a lookup from core number to full SOTA entry
    core_to_sota = {}
    for sota in sota_dict:
        core = extract_standard_number(sota)
        if core:
            core_to_sota[core] = sota  # Optional: could append to list if duplicates exist

    # Step 2: Match core numbers exactly
    for row in merged_output:
        matched_standards = set()

        for key, val in row.items():
            if key in ["Description", "SOTA", "CER", "ERC", "PRD", "Consistent", "Remarks"]:
                continue

            if val != "NA":
                core = extract_standard_number(val)
                if core and core in core_to_sota:
                    matched_standards.add(core_to_sota[core])

        if matched_standards:
            row["SOTA"] = "; ".join(sorted(matched_standards))
        else:
            row["SOTA"] = "Standard not available in the SotA link"
            row["Remarks"]="All the design input docuements need to be updated with latest version of harmonized standards"

    return merged_output

def update_consistency_flags(data):
    for item in data:
        sota = item.get("SOTA", "")
        if "standard not available in the sota link" in sota.lower():
            item["CER"] = "NO"
            item["ERC"] = "NO"
            item["PRD"] = "NO"
            item["Consistent"] = "NO"
            continue  # Skip this row

        sota_core = extract_standard_number(sota)

        # Extract core numbers from all Codes
        code1_core = extract_standard_number(item.get("Code_1", ""))
        code2_core = extract_standard_number(item.get("Code_2", ""))
        code3_core = extract_standard_number(item.get("Code_3", ""))
        code4_core = extract_standard_number(item.get("Code_4", ""))

        # CER check
        item["CER"] = "YES" if sota_core and sota_core == code1_core else "NO"
        # ERC check
        item["ERC"] = "YES" if sota_core and sota_core == code2_core else "NO"
        # PRD check: both Code_3 and Code_4 must match
        item["PRD"] = (
            "YES"
            if sota_core and sota_core == code3_core and sota_core == code4_core
            else "NO"
        )

        item["Consistent"] = (
            "YES" if item["CER"] == item["ERC"] == item["PRD"] == "YES" else "NO"
        )
    return data


def get_short_name_from_key(key):
    for partial_filename, short_name in filename_mapping.items():
        if partial_filename in key:
            return short_name
    return key  # fallback if no mapping

filename_mapping = {
    "Code_1": "CER",   # can be changed to Code_1
    "Code_2": "UNIU",
    "Code_3": "SYRS",
    "Code_4": "LRS"
}

def update_remarks_based_on_sota(data: list[dict]) -> list[dict]:
    """
    Update the 'Remarks' field for each row using SOTA comparison
    and grouped messages with short tags (CER, UNIU, …).
    """
    FIXED_KEYS = {
        "description", "SOTA", "CER", "ERC",
        "PRD", "Consistent", "Remarks"
    }

    for row in data:
        sota_std = extract_standard_number(row.get("SOTA", ""))
        if not sota_std or ":" not in sota_std:
            row["Remarks"] = (
                "All the design input documents need to be updated with "
                "latest version of harmonized standards"
            )
            continue

        sota_base, sota_year = sota_std.split(":")

        # Buckets indexed by issue type
        issues: dict[str, list[str]] = defaultdict(list)

        for col, val in row.items():
            if col in FIXED_KEYS:
                continue

            tag = get_short_name_from_key(col)

            if val == "N/A":
                issues["missing"].append(tag)
                continue

            doc_std = extract_standard_number(val)
            if not doc_std or ":" not in doc_std:
                issues["unrecognized"].append(tag)
                continue

            doc_base, doc_year = doc_std.split(":")
            if doc_base != sota_base:
                issues["different"].append(f"{tag} ({doc_std})")
            elif doc_year != sota_year:
                issues["outdated"].append(f"{tag} ({doc_std})")

        # Build human‑readable message blocks
        messages = []
        if issues["missing"]:
            messages.append(
                f"{', '.join(sorted(issues['missing']))} "
                f"document(s) missing the standard — update required"
            )
        if issues["outdated"]:
            messages.append(
                f"{', '.join(sorted(issues['outdated']))} "
                f"outdated, expected {sota_std}"
            )
        if issues["different"]:
            messages.append(
                f"{', '.join(sorted(issues['different']))} "
                f"use a different standard, expected {sota_std}"
            )
        if issues["unrecognized"]:
            messages.append(
                f"{', '.join(sorted(issues['unrecognized']))} "
                f"format not recognized"
            )

        row["Remarks"] = " | ".join(messages) if messages else \
                         "All documents aligned with latest harmonized standard"

    return data