import chromadb
import json
from chromadb.config import Settings
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)


def connect_chromadb(host, port):
    return chromadb.HttpClient(
        host=host,
        port=port,
        settings=Settings(anonymized_telemetry=False)
    )

def get_collection(client, name):
    return client.get_collection(name=name)

def retrieve_documents(collection, embedding, filter_values, where_filter, where_document, max_results, full_document_search):
    results = None
    where = ""
    
    logging.info(f"full_document_search: {full_document_search}")
    logging.info(f"where document condition: {where_document}")
    logging.info(f"where filter condition: {where_filter}")
    
    if where_document == "":
        logging.info("where_document is an empty string")
        where_document = None  # Treat empty strings as None for consistency
    elif where_document:
        try:
            where_document = json.loads(where_document)  # Attempt to parse if it's a valid JSON string
            logging.info(f"Successfully parsed where_document: {where_document}")
        except json.JSONDecodeError as e:
            logging.error(f"[ChromaDB] Invalid where_document JSON: {e}")
            where_document = None  # Set to None if parsing fails

    # Handle where_filter similarly:
    if where_filter == "":
        logging.info("where_filter is an empty string")
        where = None  # Treat empty strings as None
    elif where_filter:
        try:
            where = json.loads(where_filter)  # Try to parse where_filter if it's a string
            logging.info(f"Successfully parsed where_filter: {where}")
        except json.JSONDecodeError as e:
            logging.error(f"[ChromaDB] Invalid where_filter JSON: {e}")
            where = None  # Set to None if parsing fails

    # Full document search
    if full_document_search == "Yes":
        logging.info("Inside full document search")
        if where and where_document:
            results = collection.get(include=["documents", "metadatas"], where=where, where_document=where_document)
        elif where:
            results = collection.get(include=["documents", "metadatas"], where=where)
        elif where_document:
            results = collection.get(include=["documents", "metadatas"], where_document=where_document)
        else:
            results = collection.get(include=["documents", "metadatas"])
    
    else:  # Embedding-based similarity search
        logging.info("Inside embedding-based similarity search")
        if where and where_document:
            logging.info(f"where in both: {where}")
            results = collection.query(
                query_embeddings=[embedding],
                n_results=max_results,
                include=["documents", "metadatas"],
                where=where,
                where_document=where_document
            )
        elif where:
            logging.info(f"where: {where}")
            results = collection.query(
                query_embeddings=[embedding],
                n_results=max_results,
                include=["documents", "metadatas"],
                where=where
            )
        elif where_document:
            logging.info(f"inside where docu: {where_document}")
            results = collection.query(
                query_embeddings=[embedding],
                n_results=max_results,
                include=["documents", "metadatas"],
                where_document=where_document
            )
        elif filter_values:
            logging.info(f"inside filter: {filter_values}")
            results = collection.query(
                query_embeddings=[embedding],
                n_results=max_results,
                include=["documents", "metadatas"],
                where={"section": {"$in": filter_values}}
            )
        else:
            logging.info("inside else: No filters or where parameters provided")
            results = collection.query(
                query_embeddings=[embedding],
                n_results=max_results,
                include=["documents", "metadatas"]
            )

    return results
