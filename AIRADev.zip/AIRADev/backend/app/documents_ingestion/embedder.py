from config.config import ConfigLoader
from rag_pipeline.embeddings.ollama_embed import OllamaEmbedding
from rag_pipeline.embeddings.openai_embed import OpenAIEmbedding

def get_embedder():
    config = ConfigLoader()
    backend = config.get("embeddings", "backend", default="ollama").lower()
    if backend == "openai":
        return OpenAIEmbedding()
    return OllamaEmbedding()
