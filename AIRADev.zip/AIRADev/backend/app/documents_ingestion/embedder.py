from config.config import ConfigLoader
from rag_pipeline.embeddings.ollama_embed import OllamaEmbedding
from rag_pipeline.embeddings.openai_embed import OpenAIEmbedding

def get_embedder():
    config = ConfigLoader()
    backend = config.get("embeddings", "backend", default="ollama").lower()
    if backend == "openai":
        return OpenAIEmbedding()
    return OllamaEmbedding()

def embed_chunks_with_dynamic_backend(chunks):
    
    embedder = get_embedder()

    if hasattr(embedder, "embed_section_chunks"):
        return embedder.embed_section_chunks(chunks)

    # Fallback to individual embedding
    embeddings, valid_chunks = [], []
    for chunk in chunks:
        text = chunk.get("content", "")
        if not text.strip():
            continue
        embedding = embedder.embed(text)
        if embedding:
            embeddings.append(embedding)
            valid_chunks.append(chunk)
    return embeddings, valid_chunks
