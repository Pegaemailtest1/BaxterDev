import logging
import sys
from fastapi import FastAPI
from fastapi.responses import FileResponse
import os
from pydantic import BaseModel

from documents_ingestion.load_documents import load_documents
from documents_ingestion.chunker import split_documents, create_chunks_and_metas, split_by_sections, generate_all_chunks
from documents_ingestion.embedder import get_embedder
from documents_ingestion.vectorizer import document_vectorize, document_vectorize_by_section
from documents_ingestion.move_files_to_archive import move_files_to_archive
from documents_ingestion.remove_empty_folders import remove_empty_folders
from documents_ingestion.delete_collection import delete_collection
from retrieval.retrieve_content import retrieve_collection_data
from retrieval.generate_output_template import generate_output_template
from retrieval.generate_set2_template import generate_set2_template
from retrieval.generate_set3_template import generate_set3_template
from retrieval.retrieve_content_prompt import retrieve_collection_data_prompt

from config.constants import (
    OLLAMA_URL, EMBED_MODEL,
    CHROMA_HOST, CHROMA_PORT, COLLECTION_NAME, CHUNK_SIZE, CHUNK_OVERLAP,
    FM_MODEL, OPENAI_FM_MODEL, OPENAI_BASE_URL, OPENAI_API_KEY,
    MAX_RESULTS, TEMPERATURE, MAX_TOKENS,
    UPLOAD_FOLDER, ARCHIVE_FOLDER, INPUT_TEMPLATE_FOLDER, DOWNLOAD_TEMPLATE_FOLDER,
    LANGSMITH
)


# --- Logging setup ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

# --- FastAPI app ---

class Message(BaseModel):
    message: str

class FolderPathRequest(BaseModel):
    folder_path: str

class UserQuery(BaseModel):
    user_query: str

class PromptQuery(BaseModel):
    prompt_query: str
    full_doc_search: bool
    user_query: str

app = FastAPI()

@app.get("/")
def read_root():  
     
    return {"message": "Welcome to the RAG API"}

# Ollama API or model call
def get_ollama_response(message: str) -> str:
    # Replace with actual Ollama API call or logic
    response = f"Simulated Ollama response to: {message}"
    return response

@app.post("/get_response")
def get_response(message: Message):
    response = get_ollama_response(message.message)
    return {"response": response}


@app.post("/vectorization")
def file_vectorization(request: FolderPathRequest):
    folder_path = request.folder_path
    logging.info(f"folder_path:{folder_path}")
    
    delete_collection(CHROMA_HOST, CHROMA_PORT, COLLECTION_NAME)
    #logging.info(f"Collection deleted successfully")
    
    documents = load_documents(folder_path)    
    #logging.info(f"Documents loaded successfully: {documents}")

    chunks = generate_all_chunks(documents)
    logging.info(f"Split documents successfully:{chunks}")

    embedder = get_embedder()
    embeddings, valid_chunks = embedder.embed_section_chunks(chunks)
    #logging.info(f"embedding successfully")

    if not embeddings or not valid_chunks:
        logging.warning("No valid embeddings or chunks were generated. Skipping vectorization.")
    else:
        logging.info(f"Successfully embedded {len(valid_chunks)} chunks")

        # Vectorize only the valid chunks
        vectorize_response = document_vectorize_by_section(
            CHROMA_HOST,
            CHROMA_PORT,
            COLLECTION_NAME,
            valid_chunks,  # ✅ Use only valid chunks
            embeddings
        )

        logging.info(f"Vectorization successful: {vectorize_response}")

    # move files to destination folder
    move_files_to_archive(UPLOAD_FOLDER, ARCHIVE_FOLDER)

    # Remove empty folder
    remove_empty_folders(UPLOAD_FOLDER)
   
    return vectorize_response

@app.post("/retrieval")
def retrieval_content_from_chromadb(request: UserQuery):
    user_query = request.user_query
    logging.info(f"User query: {user_query}")

    llama_response =retrieve_collection_data(
        CHROMA_HOST,
        CHROMA_PORT,
        COLLECTION_NAME,
        EMBED_MODEL,
        user_query,
        max_results=MAX_RESULTS,
        FM_MODEL=FM_MODEL,
        OLLAMA_URL=OLLAMA_URL,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS
    )

    logging.info(f"llama_response: {llama_response}")

    return {"response": llama_response}


@app.post("/prompt")
def retrieval_content_from_chromadb_prompt(request: PromptQuery):
    prompt_query = request.prompt_query
    full_doc_search = request.full_doc_search
    user_query = request.user_query
    logging.info(f"Prompt query: {prompt_query}")

    llama_response =retrieve_collection_data_prompt(
        CHROMA_HOST,
        CHROMA_PORT,
        COLLECTION_NAME,
        EMBED_MODEL,
        prompt_query,
        full_doc_search,
        user_query,
        max_results=MAX_RESULTS,
        FM_MODEL=FM_MODEL,
        OLLAMA_URL=OLLAMA_URL,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS
    )

    logging.info(f"llama_response: {llama_response}")

    return {"response": llama_response}

@app.get("/download/{filename}")
def download_file(filename: str):
    logging.info(f"Download started for: {filename}")

    input_file_path = os.path.join(INPUT_TEMPLATE_FOLDER, filename)
    output_file_path = os.path.join(DOWNLOAD_TEMPLATE_FOLDER, filename)

    os.makedirs(DOWNLOAD_TEMPLATE_FOLDER, exist_ok=True)

    try:
        if "Set III" in filename:
            logging.info("Using Set III generation logic")
            generate_set3_template(
                input_file_path, output_file_path,
                OLLAMA_URL, EMBED_MODEL, CHROMA_HOST, CHROMA_PORT,
                COLLECTION_NAME, FM_MODEL, MAX_RESULTS, TEMPERATURE, MAX_TOKENS
            )
        elif "Set II" in filename:
            logging.info("Using Set II generation logic")
            generate_set2_template(
                input_file_path, output_file_path,
                OLLAMA_URL, EMBED_MODEL, CHROMA_HOST, CHROMA_PORT,
                COLLECTION_NAME, FM_MODEL, MAX_RESULTS, TEMPERATURE, MAX_TOKENS
            )
        else:
            logging.warning("No matching Set found in filename, using default")
            generate_output_template(
                input_file_path, output_file_path,
                OLLAMA_URL, EMBED_MODEL, CHROMA_HOST, CHROMA_PORT,
                COLLECTION_NAME, FM_MODEL, MAX_RESULTS, TEMPERATURE, MAX_TOKENS
            )

    except Exception as e:
        logging.error(f"Template generation failed: {e}")
        return {"error": str(e)}

    if os.path.exists(output_file_path):
        return FileResponse(output_file_path, filename=filename, media_type='application/octet-stream')

    return {"error": "File not found"}



@app.get("/downloaded_file/{filename}")
def downloaded_file(filename: str):

    logging.info(f"Download started")
    input_file_path = os.path.join(DOWNLOAD_TEMPLATE_FOLDER, filename)
    if os.path.exists(input_file_path):
        return FileResponse(input_file_path, filename=filename, media_type='application/octet-stream')
    return {"error": "File not found"}