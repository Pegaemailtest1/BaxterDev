from abc import ABC, abstractmethod

class LLMBackend(ABC):
    @abstractmethod
    def generate(self, context: str, question: str) -> str:
        pass
