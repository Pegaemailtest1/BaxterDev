import openai
from rag_pipeline.embeddings.base import EmbeddingBackend
from config.config import ConfigLoader

class OpenAIEmbedding(EmbeddingBackend):
    def __init__(self):
        config = ConfigLoader()
        self.api_key = config.get("llms", "openai", "api_key")
        self.model = config.get("embeddings", "openai", "model")
        self.base_url = config.get("llms", "openai", "base_url")

        # Set OpenAI API settings globally
        openai.api_key = self.api_key
        openai.base_url = self.base_url

    def embed(self, text: str) -> list[float]:
        if not text.strip():
            return []
        try:
            response = openai.Embedding.create(
                input=text,
                model=self.model,
            )
            return response["data"][0]["embedding"]
        except Exception as e:
            print(f"[OpenAIEmbedding] Error generating embedding: {e}")
            return []
