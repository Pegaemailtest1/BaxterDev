import requests
from rag_pipeline.embeddings.base import EmbeddingBackend
from config.config import ConfigLoader

class OllamaEmbedding(EmbeddingBackend):
    def __init__(self):
        config = ConfigLoader()
        self.base_url = config.get("embeddings", "ollama", "base_url")
        self.model = config.get("embeddings", "ollama", "model")

    def embed(self, text: str) -> list[float]:  # ✅ Must match abstract method
        if not text.strip():
            return []
        try:
            res = requests.post(
                f"{self.base_url}/api/embeddings",
                json={"model": self.model, "prompt": text}
            )
            res.raise_for_status()
            return res.json().get("embedding", [])
        except requests.RequestException as e:
            print(f"[OllamaEmbedding] Error: {e}")
            return []

    def embed_section_chunks(self, chunks):  # ✅ Optional helper for bulk ingestion
        embeddings = []
        valid_chunks = []
        for chunk in chunks:
            text = chunk.get("content", "")
            if not text.strip():
                continue
            emb = self.embed(text)
            if emb:
                embeddings.append(emb)
                valid_chunks.append(chunk)
        return embeddings, valid_chunks
