class RAGPipeline:
    def __init__(self, embedder, retriever, llm):
        self.embedder = embedder
        self.retriever = retriever
        self.llm = llm

    def run(self, question: str) -> str:
        embedding = self.embedder.embed(question)
        context_chunks = self.retriever.query(embedding)
        final_response = self.llm.generate("\n".join(context_chunks), question)
        return final_response