import chromadb

class ChromaRetriever:
    def __init__(self, collection_name: str):
        self.client = chromadb.Client()
        self.collection = self.client.get_or_create_collection(name=collection_name)

    def query(self, embedding: list[float], top_k=5):
        result = self.collection.query(
            query_embeddings=[embedding],
            n_results=top_k
        )
        return result["documents"][0]
