import chromadb
import requests
from chromadb.config import Settings
import logging
import sys
import json
from .generate_prompt import select_prompt_template
from .extract_components import extract_components

import base64
import re
from PIL import Image, ImageDraw
from io import BytesIO
import pytesseract
import os


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

def connect_chromadb(CHROMA_HOST, CHROMA_PORT):
    chroma_client = chromadb.HttpClient(
        host=CHROMA_HOST,
        port=CHROMA_PORT,
        settings=Settings(anonymized_telemetry=False)
    )
    return chroma_client

def get_chromadb_collection(chroma_client, collection_name):
    return chroma_client.get_collection(name=collection_name)

def embed_with_ollama(query, OLLAMA_URL, EMBED_MODEL):
    response = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": query}
    )
    response.raise_for_status()
    return response.json()["embedding"]

def ask_llama3(prompt, OLLAMA_URL, FM_MODEL, temperature, max_tokens):
    if '"response": ["No Trace"]' in prompt or '"response": "No Trace"' in prompt:
        return '{"response": ["No Trace"]}'

    response = requests.post(
        f"{OLLAMA_URL}/api/generate",
        json={"model": FM_MODEL, "prompt": prompt, "temperature": temperature, "num_predict": max_tokens}
    )
    if response.status_code == 404:
        raise Exception(f"Endpoint not found at {OLLAMA_URL}/api/generate")

    response.raise_for_status()
    full_response = ""
    for line in response.iter_lines(decode_unicode=True):
        if line:
            data = json.loads(line)
            full_response += data.get("response", "")

    return full_response

def extract_text_from_base64_image(base64_data):
    try:
        image_bytes = base64.b64decode(base64_data)
        image = Image.open(BytesIO(image_bytes)).convert("L")
        image = image.resize((image.width * 2, image.height * 2))
        return pytesseract.image_to_string(image).strip()
    except Exception as e:
        logging.error(f"Failed to OCR image: {e}")
        return ""

def extract_image_base64(document_text):
    match = re.search(r'\(base64\):\s*([A-Za-z0-9+/=]+)', document_text)
    return match.group(1) if match else None

def extract_issued_effective_dates(text):
    issued = re.search(r"Issued Date[:\-]?\s*(\d{2}/\d{2}/\d{4})", text, re.IGNORECASE)
    effective = re.search(r"Effective Date[:\-]?\s*(\d{2}/\d{2}/\d{4})", text, re.IGNORECASE)
    return {
        "issued_date": issued.group(1) if issued else None,
        "effective_date": effective.group(1) if effective else None
    }

def ocr_from_vector_path(vector_path, width=600, height=200, scale=1):
    img = Image.new("L", (width, height), color=255)
    draw = ImageDraw.Draw(img)
    pattern = re.compile(r"M(\d+),(\d+)h1v1h-1z")
    for match in pattern.finditer(vector_path):
        x, y = int(match.group(1)) * scale, int(match.group(2)) * scale
        draw.rectangle([x, y, x + scale - 1, y + scale - 1], fill=0)
    return pytesseract.image_to_string(img).strip()

def normalize_table_chunk(raw_text):
    lines = raw_text.strip().split("\n")
    normalized_lines = []
    for line in lines:
        cols = [col.strip() for col in line.split("|")]
        if len(cols) >= 2:
            normalized_lines.append(f"{cols[0]} | {cols[1]}")
    return "\n".join(normalized_lines)
    
def retrieve_collection_data(CHROMA_HOST, CHROMA_PORT, COLLECTION_NAME, EMBED_MODEL, query_text, max_results, FM_MODEL, OLLAMA_URL, temperature, max_tokens):
    client = connect_chromadb(CHROMA_HOST, CHROMA_PORT)
    collection = get_chromadb_collection(client, COLLECTION_NAME)

    extracted_components = extract_components(query_text)
    collection_filter = extracted_components.get("section")
    question = extracted_components.get("question")
    field = extracted_components.get("field")
    #logging.info(f"field: {field}")
    question_text = question + "." if question else query_text

    query_embedding = embed_with_ollama(question_text, OLLAMA_URL, EMBED_MODEL)

    filter_values = collection_filter if isinstance(collection_filter, list) else [collection_filter] if collection_filter else None
    target_doc_id = extracted_components.get("document_id")
    logging.info(f"Target document id: {target_doc_id}")

    # Filter by section if provided
    meta_filter = {}
    if field:
        meta_filter["section"] = {"$contains": field}
    if target_doc_id:
        meta_filter["source"] = {"$contains": target_doc_id}

    full_document_search = ""
    document_id = "BXU542980 Rev A_Design Validation Irrigation Sets"
    where_filter = "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU542980 Rev A_Design Validation Irrigation Sets\"}}, {\"type\": {\"$eq\": \"footer\"}}]}"
    #where_filter = ""
    #where_filter = "{\"document_id\": {\"$eq\": \"BXU535425 Rev D_User Needs\"}}"
    # Step 1: Get using one filter (e.g., by source)
    if full_document_search:
        if where_filter:
            where_filter = json.loads(where_filter)
            results = collection.get(
                include=["documents", "metadatas"],
                where=where_filter
            )
        else:
            results = collection.get(
            include=["documents", "metadatas"]
    )
    elif filter_values:
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=max_results,
            include=["documents", "metadatas"],
            where={"section": {"$in": filter_values}}
        )
    elif where_filter:
        where_filter = json.loads(where_filter)
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=max_results,
            include=["documents", "metadatas"],
            where=where_filter
        )
    else:
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=max_results,
            include=["documents", "metadatas"]
        )


    # Step 2: Apply additional filtering (e.g., exclude a specific section)
    # filtered_docs = []
    # for doc, meta in zip(results["documents"], results["metadatas"]):
    #     if meta.get("section") != "Colour Reference:":
    #         filtered_docs.append((doc, meta))
    #logging.info(f"Results: {results}")
    documents = results.get("documents", [[]])
    metadatas = results.get("metadatas", [[]])


    # logging.info(f"documents:{documents}")
    # logging.info(f"metadatas:{metadatas}")
    

    # Step 6: Filter based on metadata match
    # filtered_chunks = []
    filtered_docs = documents

    logging.info(f"Filtered chunks: {filtered_docs}")
    # Step 7: Combine into final context
    context = "\n\n".join(
        str(chunk).strip() for chunk in filtered_docs if str(chunk).strip()
    )

    
    #logging.info(f"Filtered Query results: {filtered_chunks}")
    #logging.info(f"context: {context}")

    prompt = select_prompt_template(context, query_text)

    logging.info(f"Generated prompt: {prompt}")

    llama_response = ask_llama3(prompt, OLLAMA_URL, FM_MODEL, temperature, max_tokens)

    return llama_response
