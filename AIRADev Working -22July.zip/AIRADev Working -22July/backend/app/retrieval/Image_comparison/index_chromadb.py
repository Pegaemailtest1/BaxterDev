import os
import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel
import chromadb
from chromadb.config import Settings
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
# --- Setup ---
device = "cpu"
clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(device)
clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

current_dir = os.path.dirname(os.path.abspath(__file__))
# --- Connect to Remote ChromaDB ---
def connect_chromadb(CHROMA_HOST, CHROMA_PORT):
    chroma_client = chromadb.HttpClient(
        host=CHROMA_HOST,
        port=CHROMA_PORT,
        settings=Settings(anonymized_telemetry=False)
    )
    return chroma_client

# ChromaDB connection settings
CHROMA_HOST = "chromadb"
CHROMA_PORT = 8000

# Establish connection
client = connect_chromadb(CHROMA_HOST, CHROMA_PORT)
collection_name = "image_embeddings"
collection = client.get_or_create_collection(collection_name)

# --- Functions ---
def embed_image(image_path):
    """Generate embeddings for an image using the CLIP model."""
    image = Image.open(image_path).convert("RGB")
    inputs = clip_processor(images=image, return_tensors="pt").to(device)
    with torch.no_grad():
        embeddings = clip_model.get_image_features(**inputs)
    return embeddings[0].cpu().tolist()

def index_images(root_folder):
    logging.info(f"image root folder: {root_folder}")
    root_folder= os.path.join(current_dir, root_folder)
    logging.info(f"image root folder after: {root_folder}")
    """Index images and store embeddings in ChromaDB."""
    count = 0
    for dirpath, _, filenames in os.walk(root_folder):
        for filename in filenames:
            if not filename.lower().endswith((".png", ".jpg", ".jpeg")):
                continue

            full_path = os.path.join(dirpath, filename)
            relative_path = os.path.relpath(full_path, root_folder)

            lower_path = dirpath.lower()
            if 'pouch' in lower_path:
                label = 'Pouch'
            elif 'carton' in lower_path:
                label = 'Carton'
            else:
                print(f"Skipping {full_path} as label is neither 'Carton' nor 'Pouch'")
                continue

            embedding = embed_image(full_path)
            collection.add(
                embeddings=[embedding],
                metadatas=[{"path": relative_path, "label": label}],
                ids=[relative_path]
            )
            count += 1

    print(f"✅ Total images indexed: {count}")

def query_by_label(label):
    """Query images by label from ChromaDB."""
    results = collection.get(where={"label": label}, include=["metadatas"])
    return [meta["path"] for meta in results["metadatas"]] if results["metadatas"] else []

def query_by_image_similarity(image_path, top_k=3):
    """Query similar images based on a given image."""
    embedding = embed_image(image_path)
    results = collection.query(query_embeddings=[embedding], n_results=top_k)
    return results["metadatas"], results["distances"]

def query_by_image_similarity_per_label(query_image_path):
    """Query the most similar images per label."""
    query_embedding = embed_image(query_image_path)

    all_metadata = collection.get(include=["metadatas"])["metadatas"]
    unique_labels = set(meta["label"] for meta in all_metadata if "label" in meta)

    results = []
    for label in unique_labels:
        label_results = collection.get(where={"label": label}, include=["embeddings", "metadatas"])
        embeddings = label_results["embeddings"]
        paths = [meta["path"] for meta in label_results["metadatas"]]

        if embeddings is None or len(embeddings) == 0 or not paths:
            continue

        tensor_embeddings = torch.tensor(embeddings)
        query_tensor = torch.tensor(query_embedding).unsqueeze(0)
        similarities = torch.nn.functional.cosine_similarity(query_tensor, tensor_embeddings)

        max_index = torch.argmax(similarities).item()
        max_similarity = similarities[max_index].item()

        results.append({
            "label": label,
            "path": paths[max_index],
            "similarity": max_similarity
        })

    return results

# --- Example Usage ---
if __name__ == "__main__":
    # Index images
    current_dir = os.path.dirname(os.path.abspath(__file__))
    index_folder = os.path.join(current_dir, "Labelling_icons_by_pdf")
    
    index_images(index_folder)

    # Example global similarity query
    query_image = os.path.join(current_dir, "Table", "IFU_symbol_2_395.png")
    
    metas, distances = query_by_image_similarity(query_image, top_k=3)
    print(f"\nTop similar images to '{query_image}':")
    for meta, dist in zip(metas[0], distances[0]):
        print(f"Path: {meta['path']}, Distance: {dist:.4f}")

    # Query best match per label
    print("\nMost similar image per label:")
    label_results = query_by_image_similarity_per_label(query_image)
    for result in label_results:
        print(f"Label: {result['label']}, Path: {result['path']}, Similarity: {result['similarity']:.4f}")
