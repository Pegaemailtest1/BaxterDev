import json
import os

def load_ifu_data():
    # Load the JSON data from the file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir,"IFU_Data.json")
    with open(file_path, 'r') as file:
        json_data = json.load(file)
    return json.dumps(json_data, indent=2)
    # json.dumps({"Questions": result}, indent=2)