
from sqlalchemy import create_engine, Table, Column, String, Integer, Date, MetaData
from sqlalchemy.orm import declarative_base, sessionmaker
import os

# Database configuration from environment variables (injected via Docker Compose)
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")  # use 'db' if running inside container
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")

# SQLAlchemy engine setup
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()
metadata = MetaData()

# Reflect (declare) existing tables from the DB
submissions = Table("submissions", metadata, autoload_with=engine)
users = Table("users", metadata, autoload_with=engine)
product_files = Table("product_files", metadata, autoload_with=engine)

# Optional: test connection
if __name__ == "__main__":
    try:
        with engine.connect() as conn:
            print("✅ Connected to DB. Tables are ready for use.")
    except Exception as e:
        print("❌ Failed to connect:", e)

