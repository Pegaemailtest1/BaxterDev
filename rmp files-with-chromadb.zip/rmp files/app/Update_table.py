import csv

import psycopg2
 
def update_appendix_b_from_csv(csv_file: str, db_config: dict):

    # --- Clean value: convert NaN, NUL, or empty to None, cast numbers where needed ---

    def clean_value(value, field_type):

        if value in ('', 'NaN', 'NUL', None):

            return None

        try:

            if field_type == 'real':

                return float(value)

            return value

        except ValueError:

            return None
 
    # --- Column types: match your table ---

    column_types = {

        'hazardous_situation_id': 'text',

        'critical_qualitative': 'text',

        'moderate_qualitative': 'text',

        'minor_qualitative': 'text',

        'critical_semi_quantitative': 'real',

        'moderate_semi_quantitative': 'real',

        'minor_semi_quantitative': 'real',

        'probability_of_hazardous_situation_p1': 'real',

        'critical': 'real',

        'moderate': 'real',

        'minor': 'real',

        'critical_pharm_qualitative': 'text',

        'moderate_pharm_qualitative': 'text',

        'minor_pharm_qualitative': 'text',

    }
 
    # --- Read and process CSV ---

    try:

        with open(csv_file, mode='r', newline='', encoding='utf-8') as file:

            reader = csv.DictReader(file)

            rows = list(reader)

    except Exception as e:

        print(f"❌ Error reading CSV: {e}")

        return
 
    # --- Connect to DB ---

    try:

        conn = psycopg2.connect(**db_config)

        cur = conn.cursor()

    except Exception as e:

        print(f"❌ Database connection error: {e}")

        return
 
    # --- Build and run updates ---

    updated_count = 0

    for row in rows:

        cleaned = {

            col: clean_value(row[col], column_types[col])

            for col in column_types

        }
 
        sql = """

            UPDATE appendix_b_p2_conversion

            SET

                critical_qualitative = %s,

                moderate_qualitative = %s,

                minor_qualitative = %s,

                critical_semi_quantitative = %s,

                moderate_semi_quantitative = %s,

                minor_semi_quantitative = %s,

                probability_of_hazardous_situation_p1 = %s,

                critical = %s,

                moderate = %s,

                minor = %s,

                critical_pharm_qualitative = %s,

                moderate_pharm_qualitative = %s,

                minor_pharm_qualitative = %s

            WHERE hazardous_situation_id = %s

        """
 
        values = [

            cleaned['critical_qualitative'],

            cleaned['moderate_qualitative'],

            cleaned['minor_qualitative'],

            cleaned['critical_semi_quantitative'],

            cleaned['moderate_semi_quantitative'],

            cleaned['minor_semi_quantitative'],

            cleaned['probability_of_hazardous_situation_p1'],

            cleaned['critical'],

            cleaned['moderate'],

            cleaned['minor'],

            cleaned['critical_pharm_qualitative'],

            cleaned['moderate_pharm_qualitative'],

            cleaned['minor_pharm_qualitative'],

            cleaned['hazardous_situation_id'],

        ]
 
        try:

            cur.execute(sql, values)

            updated_count += 1

        except Exception as e:

            print(f"⚠️ Error updating ID {cleaned['hazardous_situation_id']}: {e}")
 
    # --- Commit and close ---

    conn.commit()

    cur.close()

    conn.close()
 
    print(f"✅ Update complete. Rows processed: {len(rows)}. Rows updated: {updated_count}.")
 
# Example usage

if __name__ == '__main__':

    db_config = {

        'dbname': 'baxterdb',

        'user': 'baxterdev',

        'password': 'Password123',

        'host': 'localhost',

        'port': '5432'

    }
 
    update_appendix_b_from_csv('Appendix_B.csv', db_config)

 