import psycopg2

try:
    conn = psycopg2.connect(
        host="127.0.0.1",
        port=5432,
        database="baxterdb",
        user="baxterdev",
        password="Password@123!"
    )
    print("✅ psycopg2 connected successfully!")
    conn.close()
except Exception as e:
    print("❌ psycopg2 connection failed:")
    print(e)
