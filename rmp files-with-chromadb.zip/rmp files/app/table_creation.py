import os
from openai import AzureOpenAI
from PyPDF2 import PdfReader
import pdfplumber
import json
import re
 
endpoint = "https://aira-openai-dev.openai.azure.com/"
model_name = "gpt-4o"
deployment = "gpt-4o"
 
subscription_key = "EG1uazO0jiGj18BYA75kZu0WsYB690W0mHvBVUrefExzKCFudio6JQQJ99BFACYeBjFXJ3w3AAABACOG2skg"
api_version = "2024-12-01-preview"
 
client = AzureOpenAI(
    api_version=api_version,
    azure_endpoint=endpoint,
    api_key=subscription_key,
)
 
# Load PDF content
def extract_text_from_pdf(file_path):
    reader = PdfReader(file_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text.strip()
 
# Ask question to GPT with context
def ask_question(context, question):
    try:
        response = client.chat.completions.create(
            model=model_name,  # Azure-specific: use 'engine' instead of 'model'
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Use the context to answer questions."},
                {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"}
            ],
            temperature=0.1,
            max_tokens=1024,
            top_p=1.0,
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"[Error]: {e}"
 
def extract_pdf_text_and_tables(file_path):
    full_text = ""
    tables = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            full_text += page.extract_text() + "\n"
            page_tables = page.extract_tables()
            for table in page_tables:
                tables.append(table)
    return full_text, tables
 
def generate_text_file(filename, question, answer):
    with open(filename, "a", encoding="utf-8") as f:  # 'a' = append mode
        #f.write("----------------------------\n")
        #f.write(f"Q: {question}\n")S
        f.write(f"A: {answer}\n\n")
 
#prompt="""extract PHarm Conversions from the document :"""
 
prompt1="""
extract PHarm Conversions from the document :
 
Return the results in the following JSON format:
 
```json
[
  {
    "Individual Residual Risk": ,
    "Critical": ,
    "Moderate":,
    "Minor":
  },
  ...
]
```
 
**Example Output:**
 
```json
[
  {
    "Individual Residual Risk": "1-7",
    "Critical": "Medium",
    "Moderate": "Low",
    "Minor": "N/A"
  },
  ...
]
```
 
 
"""
 
 
prompt="""
extract Therapy Occurrence Conversions from the document :
 
Return the results in the following JSON format:
 
```json
[
  {
    "Therapy Occurrences": "<Therapy>",
    "Qualitative": "<qualitative>",
    "Quantitative (OPM)":"<quant>"
  },
  ...
]
```
 
**Example Output:**
 
```json
[
  {
    "Therapy Occurrences": "Expected",
    "Qualitative": "7",
    "Quantitative (OPM)":"> 500,000"
  },
  ...
]
```
 
 
"""


 
def save_llm_markdown_json_to_jsonl(answer_str, output_file):
    """
    Extracts JSON array from LLM response (with markdown code block formatting)
    and writes each object to a JSONL file.
    Parameters:
    - answer_str (str): LLM output as a string (including ```json and ```).
    - output_file (str): Path to save the .jsonl file.
    """
    # Extract the content between triple backticks
    match = re.search(r"```(?:json)?\s*(.*?)\s*```", answer_str, re.DOTALL)
    if not match:
        print("No valid JSON block found in the response.")
        return
 
    json_block = match.group(1).strip()
 
    try:
        data = json.loads(json_block)
    except json.JSONDecodeError as e:
        print("Failed to decode JSON:", e)
        return
 
    # Write each JSON object as a line
    with open(output_file, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
 
def content_creation():
    pdf_path = "sample3.pdf"  # Replace with your filename
    print("🔍 Loading PDF content...")
    context = extract_pdf_text_and_tables(pdf_path)
    #print(f"context: {context}")
    if not context:
        print("❌ Failed to read content from the PDF.")
        return
 
    print("✅ PDF loaded. You can now ask questions. Type 'exit' to quit.\n")
 
    answer = ask_question(context, prompt)
    #generate_text_file("table.txt",prompt,answer)
    print(f"\n💡 Answer:\n{answer}\n")
    save_llm_markdown_json_to_jsonl(answer, "therapy_ocurrences.jsonl")
    answer = ask_question(context, prompt1)
    #generate_text_file("table.txt",prompt,answer)
    print(f"\n💡 Answer:\n{answer}\n")
    save_llm_markdown_json_to_jsonl(answer, "Pharm_conversions.jsonl")
 
    # while True:
    #     question = input("❓ Your question: ").strip()
    #     print(f"Question: {question}")
    #     if question.lower() in ["exit", "quit"]:
    #         print("👋 Exiting application.")
    #         break
    #     answer = ask_question(context, question)
    #     generate_text_file("azure_answers.txt",question,answer)
    #     print(f"\n💡 Answer:\n{answer}\n")
 
 
if __name__ == "__main__":
    content_creation()