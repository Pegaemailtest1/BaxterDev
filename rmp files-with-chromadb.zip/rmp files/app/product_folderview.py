import os
import uuid
import json
from datetime import datetime, timedelta
from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, FileResponse
from fastapi import HTTPException
from sqlalchemy import select, insert
from models import engine, product_files

UPLOAD_DIR = "upload product files"
TIMER_FILE = "timer_start.json"
TIMER_DURATION = timedelta(days=730)

router = APIRouter()
templates = Jinja2Templates(directory="templates")

def get_logged_in_username(request: Request):
    return request.cookies.get("username", "")

def initialize_timer():
    if not os.path.exists(TIMER_FILE):
        with open(TIMER_FILE, "w") as f:
            json.dump({"start_time": datetime.now().isoformat()}, f)

def get_remaining_time():
    if not os.path.exists(TIMER_FILE):
        return TIMER_DURATION
    with open(TIMER_FILE, "r") as f:
        data = json.load(f)
        start_time = datetime.fromisoformat(data["start_time"])
        end_time = start_time + TIMER_DURATION
        now = datetime.now()
        return max(end_time - now, timedelta(seconds=0))

# Initialize timer when this module is loaded
initialize_timer()

def sync_folder_to_db():
    with engine.begin() as conn:
        for folder in os.listdir(UPLOAD_DIR):
            folder_path = os.path.join(UPLOAD_DIR, folder)
            if os.path.isdir(folder_path):
                for file_name in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, file_name)
                    exists = conn.execute(select(product_files).where(product_files.c.file_path == file_path)).first()
                    if not exists:
                        conn.execute(insert(product_files).values(
                            id=str(uuid.uuid4()),
                            folder_name=folder,
                            file_name=file_name,
                            file_path=file_path
                        ))

@router.get("/product-folders", response_class=HTMLResponse)
def list_product_folders(request: Request):
    try:
        sync_folder_to_db()
        folders = {}
        with engine.connect() as conn:
            results = conn.execute(select(product_files.c.folder_name).distinct()).fetchall()
            for (folder,) in results:
                count = conn.execute(select(product_files).where(product_files.c.folder_name == folder)).rowcount
                folders[folder] = count
        username = get_logged_in_username(request)
        return templates.TemplateResponse("profolder.html", {
            "request": request,
            "folders": folders,
            "username": username
        })
    except Exception as e:
        return templates.TemplateResponse("profolder.html", {
            "request": request,
            "folders": {},
            "error": str(e),
            "username": get_logged_in_username(request)
        })

@router.get("/product-folders/view/{folder_name}", response_class=HTMLResponse)
def view_product_folder(request: Request, folder_name: str):
    with engine.connect() as conn:
        files = conn.execute(select(product_files).where(product_files.c.folder_name == folder_name)).fetchall()

    remaining = get_remaining_time()
    total_seconds = int(remaining.total_seconds())
    username = get_logged_in_username(request)

    return templates.TemplateResponse("profoldview.html", {
        "request": request,
        "folder_name": folder_name,
        "files": files,
        "remaining_seconds": total_seconds,
        "username": username
    })

@router.get("/product-folders/download/{file_id}", response_class=FileResponse)
def download_product_file(file_id: str):
    with engine.connect() as conn:
        file_record = conn.execute(select(product_files).where(product_files.c.id == file_id)).first()

    if not file_record:
        raise HTTPException(status_code=404, detail="File not found")

    if not os.path.exists(file_record.file_path):
        raise HTTPException(status_code=404, detail="File not found on disk")

    return FileResponse(path=file_record.file_path, filename=file_record.file_name, media_type='application/octet-stream')
