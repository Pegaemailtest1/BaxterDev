from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from .standard_normalization import extract_standard_number
import os
import time

def extract_standard_data(standard):
    remote_url = os.environ.get("SELENIUM_REMOTE_URL", "http://chrome:4444/wd/hub")
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--enable-javascript")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("--window-size=1920,1080")

    result = {
        "standard": standard,
        "url": "",
        "extracted": []
    }

    try:
        print("🟡 Initializing WebDriver...")
        driver = webdriver.Remote(command_executor=remote_url, options=options)
        wait = WebDriverWait(driver, 30)

        print(f"🌐 Navigating to: https://store.accuristech.com/")
        driver.get("https://store.accuristech.com/")
        wait.until(lambda d: d.execute_script("return document.readyState") == "complete")
        time.sleep(2)

        # 🔎 Search input
        print("🔎 Waiting for search input field...")
        try:
            search_input = wait.until(EC.presence_of_element_located((
                By.CSS_SELECTOR,
                "input.ais-SearchBox-input"
            )))
            print("✅ Search input found")
        except Exception as e:
            print(f"❌ Search input not found: {e}")
            driver.save_screenshot(f"debug_input_not_found_{standard.replace(' ', '_')}.png")
            with open(f"debug_input_not_found_{standard.replace(' ', '_')}.html", "w", encoding="utf-8") as f:
                f.write(driver.page_source)
            return result

        # Search term
        search_input.clear()
        search_input.send_keys(standard)
        search_input.send_keys(Keys.RETURN)

        print("⌛ Waiting for search results...")
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".ais-Hits-item")))
        time.sleep(2)

        hit_items = driver.find_elements(By.CSS_SELECTOR, ".ais-Hits-item")
        if not hit_items:
            print(f"⚠️ No results found for {standard}")
            return result

        try:
            link = hit_items[0].find_element(By.CSS_SELECTOR, "a[href^='/searches/']")
            link.click()
        except Exception:
            hit_items[0].click()

        time.sleep(2)
        result["url"] = driver.current_url

        print("📄 Extracting product details...")
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".product_detail")))
        items = driver.find_elements(By.CSS_SELECTOR, ".product_detail")

        if not items:
            print(f"⚠️ No product details found for {standard}")
            return result

        for item in items:
            lines = item.text.strip().split('\n')
            meta_index = next((i for i, line in enumerate(lines) if line.lower().startswith("standard")), -1)

            pre_meta = lines[:meta_index] if meta_index != -1 else lines
            metadata = " ".join(lines[meta_index:]) if meta_index != -1 else ""

            title = pre_meta[0].strip() if pre_meta else ""
            description = " ".join(pre_meta[1:]) if len(pre_meta) > 1 else ""

            result["extracted"].append({
                "title": title,
                "description": description,
                "metadata": metadata
            })

    except Exception as e:
        print(f"❌ Error: {e}")
        driver.save_screenshot(f"debug_{standard.replace(' ', '_')}.png")
        with open(f"debug_{standard.replace(' ', '_')}.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)

    finally:
        driver.quit()
        print("✅ Done and driver closed.")

    return result


def extract_description_for_standard(standard):
    if ":" not in standard:
        return "Not a Valid Standard"

    result = extract_standard_data(standard)
    extracted_entries = result["extracted"]

    if not extracted_entries:
        return "No Match Found"

    input_standard_num = extract_standard_number(standard)

    # Exact match
    for entry in extracted_entries:
        if "This document has been replaced" in entry["description"]:
            continue
        if standard.strip() == entry["title"].strip():
            return entry["description"]

    # Normalized fallback
    try:
        norm_input, year_input = input_standard_num.split(":")
    except:
        return "No Match Found"

    for entry in extracted_entries:
        try:
            norm_title, year_title = extract_standard_number(entry["title"].strip()).split(":")
        except:
            continue

        if norm_input == norm_title:
            return entry["description"]

        if norm_input.split("-")[0] == norm_title.split("-")[0] and year_input == year_title:
            return entry["description"]

    return "No Match Found"
