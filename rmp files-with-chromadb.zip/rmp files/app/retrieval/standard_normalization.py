import re

def extract_standard_number(standard: str) -> str:
    """
    Normalize and extract core ISO number in form 'xxxx-x:yyyy'
    """
    standard = re.sub(r':\s+', ':', standard)

    match = re.search(r'(\d{4,5}-\d+):\d{4}', standard)
    if match:
        return match.group(0)

    match = re.search(r'(\d{4,5}-\d+)', standard)
    if match:
        return match.group(0)

    match = re.search(r'(\d{4,5})', standard)
    if match:
        return match.group(0)

    return standard.strip()
