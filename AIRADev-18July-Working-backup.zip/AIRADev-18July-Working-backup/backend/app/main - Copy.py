import logging
import sys
from fastapi import FastAPI, BackgroundTasks
from fastapi.responses import FileResponse
import os
from pydantic import BaseModel

from documents_ingestion.load_documents import load_documents
from documents_ingestion.chunker import split_documents, create_chunks_and_metas, split_by_sections, generate_all_chunks
from documents_ingestion.embedder import embed_chunks_with_dynamic_backend
from documents_ingestion.vectorizer import document_vectorize, document_vectorize_by_section
from documents_ingestion.move_files_to_archive import move_files_to_archive
from documents_ingestion.remove_empty_folders import remove_empty_folders
from documents_ingestion.delete_collection import delete_collection
from retrieval.generate_output_template import generate_output_template
from retrieval.generate_set2_template import generate_set2_template
from retrieval.generate_set3_template import generate_set3_template
from retrieval.asl.generate_set3_asl_template import generate_set3_asl_template
from retrieval.retrieve_content_prompt import retrieve_content_prompt
from config.config_loader import ConfigLoader
from config.model_factory import get_llm_and_embedder
from retrieval.retrieve_content import retrieve_content

#Images imports
# from retrieval.Image_comparison.icon_extractor import extract_icons_from_pdf
# from retrieval.Image_comparison.index_chromadb import index_images
# from retrieval.Image_comparison.Query_chromadb import store_images_into_remote_chromadb

# --- Logging setup ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

# --- FastAPI app ---
class Message(BaseModel):
    message: str

class FolderPathRequest(BaseModel):
    folder_path: str

class UserQuery(BaseModel):
    user_query: str

class PromptQuery(BaseModel):
    prompt_query: str
    full_doc_search: bool
    user_query: str

app = FastAPI()

config_loader = ConfigLoader()
llm, embedder = get_llm_and_embedder(config_loader)

pipeline_config = {
    "embedder": embedder,
    "llm": llm,
    "chroma_host": config_loader.get("storage", "chroma", "host"),
    "chroma_port": config_loader.get("storage", "chroma", "port"),
    "collection": config_loader.get("storage", "chroma", "collection_name"),
    "postgres_host": config_loader.get("storage", "postgresql", "host"),
    "postgres_port": config_loader.get("storage", "postgresql", "port"),
    "postgres_db": config_loader.get("storage", "postgresql", "dbname"),
    "postgres_user": config_loader.get("storage", "postgresql", "user"),
    "postgres_password": config_loader.get("storage", "postgresql", "password"),
    "max_results": config_loader.get("generation", "max_results", default=5),
    "temperature": config_loader.get("generation", "temperature", default=0.4),
    "max_tokens": config_loader.get("generation", "max_tokens", default=2048),
    "sotafile_path": config_loader.get("data", "sotafile_path"),
    "where_filter": "",
    "full_document_search": False
}

@app.get("/")
def read_root():
    return {"message": "Welcome to the RAG API"}

@app.post("/get_response")
def get_response(message: Message):
    response = f"Simulated Ollama response to: {message.message}"
    return {"response": response}

@app.post("/vectorization")
def file_vectorization(request: FolderPathRequest):
    folder_path = request.folder_path
    logging.info(f"folder_path:{folder_path}")

    # delete_collection(
    #     pipeline_config["chroma_host"],
    #     pipeline_config["chroma_port"],
    #     pipeline_config["collection"]
    # )

    documents = load_documents(folder_path)
    chunks = generate_all_chunks(documents)
    logging.info(f"Split documents successfully:{chunks}")

    embeddings, valid_chunks = embed_chunks_with_dynamic_backend(chunks, config_loader)

    if not embeddings or not valid_chunks:
        logging.warning("No valid embeddings or chunks were generated. Skipping vectorization.")
    else:
        logging.info(f"Successfully embedded {len(valid_chunks)} chunks")
        vectorize_response = document_vectorize_by_section(
            pipeline_config["chroma_host"],
            pipeline_config["chroma_port"],
            pipeline_config["collection"],
            valid_chunks,
            embeddings
        )
        logging.info(f"Vectorization successful: {vectorize_response}")

    move_files_to_archive(config_loader.get("data", "upload_folder"), config_loader.get("data", "archive_folder"))
    remove_empty_folders(config_loader.get("data", "upload_folder"))

    return vectorize_response

@app.post("/retrieval")
def retrieval_content_from_chromadb(request: UserQuery):
    user_query = request.user_query
    logging.info(f"User query: {user_query}")

    pipeline_config["full_document_search"] = False
    response = retrieve_content(pipeline_config, user_query)

    logging.info(f"llm_response: {response}")
    return {"response": response}

@app.post("/prompt")
def retrieval_content_from_chromadb_prompt(request: PromptQuery):
    prompt_query = request.prompt_query
    full_doc_search = request.full_doc_search
    user_query = request.user_query
    logging.info(f"Prompt data: {prompt_query} | Full Document Search: {full_doc_search} | User Query: {user_query}")

    response = retrieve_content_prompt(pipeline_config, user_query, prompt_query, full_doc_search)

    logging.info(f"llm_response: {response}")
    return {"response": response}

@app.get("/download/{filename}")
def download_file(filename: str):
    logging.info(f"Download started for: {filename}")

    input_file_path = os.path.join(config_loader.get("data", "input_template_folder"), filename)
    output_file_path = os.path.join(config_loader.get("data", "download_template_folder"), filename)

    os.makedirs(os.path.dirname(output_file_path), exist_ok=True)

    try:
        if "Set II" in filename:
            logging.info("Using Set II generation logic")
            # run_full_processing()
            generate_set2_template(input_file_path, output_file_path, pipeline_config)
        elif "Set III" in filename:
            logging.info("Using Set III generation logic")
            generate_set3_template(input_file_path, output_file_path, pipeline_config)
        elif "Set-III-asl" in filename:
            logging.info("Using Set-III-asl generation logic")
            generate_set3_asl_template(input_file_path, output_file_path, pipeline_config)
        else:
            logging.warning("No matching Set found in filename, using default")
            generate_output_template(input_file_path, output_file_path, pipeline_config)

    except Exception as e:
        logging.error(f"Template generation failed: {e}")
        return {"error": str(e)}

    if os.path.exists(output_file_path):
        return FileResponse(output_file_path, filename=filename, media_type='application/octet-stream')

    return {"error": "File not found"}

@app.get("/downloaded_file/{filename}")
def downloaded_file(filename: str):
    logging.info(f"Download started")
    input_file_path = os.path.join(config_loader.get("data", "download_template_folder"), filename)
    if os.path.exists(input_file_path):
        return FileResponse(input_file_path, filename=filename, media_type='application/octet-stream')
    return {"error": "File not found"}

# @app.get("/process_all_images/")
# async def process_all_images(background_tasks: BackgroundTasks):
#     background_tasks.add_task(run_full_processing)
#     return {"status": "Processing started in background"}

# def run_full_processing():
#     extract_icons_from_pdf("RMC4916_0736003737_POUCH_LABEL.pdf")
#     extract_icons_from_pdf("RMC4916_0738002356_Carton_LABEL.pdf")
#     index_images("Labelling_icons_by_pdf")
#     store_images_into_remote_chromadb()
