def questions_CER():
    QUESTION_TEMPLATES = {
        "Questions": [
            {
                "column": "9",
                "row": "13",
                "dictionary_element": "Date",
                "document_id": "BXU601670_MDR_CER,A",
                "type":"group",
                "group": [
                    {
                        "question": "Extract the document id and revision from the document {document_id} for product {product_code}.",
                        "prompt_template": "document_id_and_revision_CER",
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"header\"}}]}",
                
                    },
                    {
                        "question": "Extract the issued date from the document {document_id} for product {product_code}.",
                        "prompt_template": "issued_date_CER",
                        "max_results":1,
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"header-date\"}}]}",
                
                    },
                    {
                        "question": "Extract the section number of intended purpose from the document {document_id} for product {product_code}.",
                        "prompt_template": "section_number_CER",
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"section-text\"}}]}",
                    }
                ]
            },
            {
                "column": "9",
                "row": "14",
                "dictionary_element": "Date",
                "document_id": "BXU601670_MDR_CER,A",
                "type":"group",
                "group": [
                    {
                        "question": "Extract the document id and revision from the document {document_id} for product {product_code}.",
                        "prompt_template": "document_id_and_revision_CER",
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"header\"}}]}",
                
                    },
                    {
                        "question": "Extract the issued date from the document {document_id} for product {product_code}.",
                        "prompt_template": "issued_date_CER",
                        "max_results":1,
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"header-date\"}}]}",
                
                    },
                    {
                        "question": "Extract the section number of indication from the document {document_id} for product {product_code}.",
                        "prompt_template": "section_number_CER",
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"section-text\"}}]}"
                    }
                ]
            },
            {
                "column": "9",
                "row": "15",
                "dictionary_element": "Date",
                "document_id": "BXU601670_MDR_CER,A",
                "type":"group",
                "group": [
                    {
                        "question": "Extract the document id and revision from the document {document_id} for product {product_code}.",
                        "prompt_template": "document_id_and_revision_CER",
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"header\"}}]}",
                
                    },
                    {
                        "question": "Extract the issued date from the document {document_id} for product {product_code}.",
                        "prompt_template": "issued_date_CER",
                        "max_results":1,
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"header-date\"}}]}",
                
                    },
                    {
                        "question": "Extract the section number of Contraindications from the document {document_id} for product {product_code}.",
                        "prompt_template": "section_number_CER",
                        "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"section-text\"}}]}"
                    }
                ]
            },
            {
                "question": "Extract the intended purpose from the document {document_id} for product {product_code}",
                "column": "10",
                "row": "13",
                "dictionary_element": "Intended Use",
                "prompt_template": "intended_purpose_CER",
                "document_id": "BXU601670_MDR_CER,A",
                "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"section-text\"}}]}",
            },
            {
                "question": "Extract the indication from the document {document_id} for product {product_code}.",
                "column": "10",
                "row": "14",
                "dictionary_element": "Indication for Use",
                "prompt_template": "indication_for_use_CER",
                "document_id": "BXU601670_MDR_CER,A",
                "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"table\"}}]}",
            },
            {
                "question": "Extract the Contraindications from the document {document_id} for product {product_code}.",
                "column": "10",
                "row": "15",
                "dictionary_element": "Contraindications",
                "prompt_template": "contraindications_CER",
                "document_id": "BXU601670_MDR_CER,A",
                "where_filter": "{\"$and\": [{\"document_id\": {\"$eq\": \"BXU601670_MDR_CER,A\"}}, {\"type\": {\"$eq\": \"section-text\"}}]}"
            }
        ]
    }

    return QUESTION_TEMPLATES

