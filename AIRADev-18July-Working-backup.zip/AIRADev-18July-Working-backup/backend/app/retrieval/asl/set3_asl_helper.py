import pandas as pd
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import gc,re
import openpyxl
import os
from openpyxl.styles import Border, Side

file_path = "./input/asl.xlsx"
output_file_path="./output"
template_file_path = "./Template/Set-III-Template.xlsx"


def extract_max_year(text):
    if pd.isna(text):
        return None
    years = re.findall(r'(?:18|19|20)\d{2}', str(text))
    years = list(map(int, years))
    return max(years) if years else None

def read_standards_from_excel(file_path, sheet_name=0):
    # Read the Excel sheet
    df = pd.read_excel(file_path, sheet_name=sheet_name)

    # Apply the filters
    filtered_df = df[
        (df.iloc[:, 2].astype(str).str.contains("Standard", case=False, na=False)) &
        (df.iloc[:, 3].astype(str).str.lower() == 'y') &
        (df.iloc[:, 8].astype(str).str.contains("inter", case=False, na=False))
    ]

    # Extract Reference_number from column E (index 4) and Version from column F (index 5)
    result = [
        {
            "Title": str(row[6]).strip(),
            "CER":"N/A",
            "UNINU":"N/A",
            "SYRS":"N/A",
            "LRS":"N/A",
            "ASL": str(row[4]).strip(),
            "Version": str(row[5]).strip(),
            "MaxVersion":extract_max_year(str(row[5]).strip()),
            "ExtentofRecognition":"",
            "Matched":"",
            "Year_Extracted":"",
            "Remarks":""
        }
        for row in filtered_df.itertuples(index=False)
    ]

    return result

def extract_reference_number_to_search(text):
    if '/' in text:
        return text.split('/')[-1].strip()
    return text.strip()

def initialize_driver():
    remote_url = os.environ.get("SELENIUM_REMOTE_URL", "http://chrome:4444/wd/hub")
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--enable-javascript")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36")
  

    # options.add_argument('--headless')  # Uncomment if you want headless mode
    # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    driver = webdriver.Remote(
        command_executor=remote_url,
        options=options
    )
    wait = WebDriverWait(driver, 30)
    return driver

def get_web_scrap_data(driver,standard_number):
    try:
        driver.get("https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfStandards/search.cfm")
        try:
            WebDriverWait(driver, 60).until(
                EC.presence_of_element_located((By.ID, "title"))
            )
            
            input_field = driver.find_element(By.ID, "title")
            input_field.clear()
            input_field.send_keys(standard_number + Keys.RETURN)
            print(f"✅ Entered standard number and submitted: {standard_number}")
        except TimeoutException:
                print("⏱ Timeout waiting for element!")
                res= [
                    {
                        "Date of Entry": "Timeout",
                        "Specialty Task Group Area": "Timeout",
                        "Recognition Number": "Timeout",
                        "Extent of Recognition": "Timeout",
                        "Standards Developing Organization": "Timeout",
                        "Standard Designation Number and Date": "Timeout",
                        "Standard Title (click for recognition information)": "Timeout"
                    }
                ]
                return res

        try:
            WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.ID, "stds-results-table"))
            )
            print("✅ 'stds-results-table' detected after search.")
        except TimeoutException:
            print("❌ 'stds-results-table' not found after waiting 10 seconds.")
            res= [
                {
                    "Date of Entry": "Not Found",
                    "Specialty Task Group Area": "Not Found",
                    "Recognition Number": "Not Found",
                    "Extent of Recognition": "Not Found",
                    "Standards Developing Organization": "Not Found",
                    "Standard Designation Number and Date": "Not Found",
                    "Standard Title (click for recognition information)": "Not Found"
                }
            ]
            return res

        table = driver.find_element(By.ID, "stds-results-table")
        rows = table.find_elements(By.TAG_NAME, "tr")

        data_list = []
        headers = []
        previous_row_data = []

        for idx, row in enumerate(rows):
            cells = row.find_elements(By.TAG_NAME, "td")
            if not cells:
                cells = row.find_elements(By.TAG_NAME, "th")

            row_data = [cell.text.strip().replace('\n', ' ') for cell in cells]

            if not any(row_data):
                continue

            if idx == 0 and 'New Search Export' in row_data[0]:
                continue

            if not headers:
                headers = row_data
            else:
                # Pad row_data to match headers length
                while len(row_data) < len(headers):
                    row_data.insert(0, "")

                # Fill empty cells with previous row's corresponding value
                if previous_row_data:
                    row_data = [
                        current if current else previous
                        for current, previous in zip(row_data, previous_row_data)
                    ]

                row_dict = dict(zip(headers, row_data))
                data_list.append(row_dict)
                previous_row_data = row_data  # Update for next iteration

            gc.collect()

        print(f"Total Rows Fetched: {len(data_list)}")
        #return json.dumps(data_list, indent=4)
        return data_list

    except Exception as e:
        print(f"❌ Error: {e}")
        #return json.dumps([], indent=4)
        res= [
                {
                    "Date of Entry": "exception",
                    "Specialty Task Group Area": "exception",
                    "Recognition Number": "exception",
                    "Extent of Recognition": "exception",
                    "Standards Developing Organization": "exception",
                    "Standard Designation Number and Date": "exception",
                    "Standard Title (click for recognition information)": "exception"
                }
            ]
        return res

def write_data_to_excel(template_path, output_path, data):
    # Clean up newlines from Description
    # for row in data:
    #     row["Description"] = row["Description"].replace('\n', ' ')

    # Load the workbook and the first sheet
    wb = openpyxl.load_workbook(template_path)
    ws = wb.active

    # Define the order of the fields (add Column1 first)
    columns = ["Column1"] + list(data[0].keys())

    # Start writing from row 13
    start_row = 13

    # Thin border for all sides
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
        
    for idx, row_data in enumerate(data, start=1):
        row_values = [idx]  # Column1 value
        row_values.extend(row_data[col] for col in columns[1:])

        for col_idx, value in enumerate(row_values, start=1):
            cell = ws.cell(row=start_row + idx - 1, column=col_idx)
            cell.value = value
            cell.border = thin_border  # Apply border

    # Ensure output folder exists
    # os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Save the updated Excel file
    wb.save(output_path)

    print(f"Excel file written to: {output_path}")


def parse_reference(reference_number):
    parts = reference_number.strip().split(maxsplit=1)
    if len(parts) == 2:
        return parts[0], parts[1]
    elif len(parts) == 1:
        return "", parts[0]  # No org, just standard number
    else:
        raise ValueError("Empty reference number")


def extract_year(text):
    match = re.search(r'\b(19|20)\d{2}\b', text)
    return match.group(0) if match else None


def match_reference(input_list, reference_number):
    org, std_number = parse_reference(reference_number)
    
    # Collect all matches
    matches = []
    for item in input_list:
        dev_org = item.get("Standards Developing Organization", "").strip()
        std_text = item.get("Standard Designation Number and Date", "")

        if dev_org == org and std_number in std_text:
            matches.append(item)

    if not matches:
        return [{
            "Matched": "No",
            "Extent of Recognition": "Not Found",
            "Year Extracted": "0000",
            "Standard Number Found": "Not Found",
            "ASL": ""
        }]

    # Prefer the one with "Extent of Recognition" == "Complete"
    preferred = None
    for item in matches:
        if item.get("Extent of Recognition", "").strip().lower() == "complete":
            preferred = item
            break

    if not preferred:
        preferred = matches[0]

    year = extract_year(preferred.get("Standard Designation Number and Date", ""))
    asl_ref_num = preferred.get("ASL", "").strip()

    return [{
        "Matched": "Yes",
        "Extent of Recognition": preferred.get("Extent of Recognition", "").strip(),
        "Year Extracted": year,
        "Standard Number Found": std_number,
        "ASL": asl_ref_num
    }]

def update_remarks(ExtentofRecognition, yearfromWeb, yearfromexcel):
    print(f"ExtentofRecognition: {ExtentofRecognition}")
    print(f"yearfromexcel:{yearfromexcel}")
    print(f"yearfromWeb:{yearfromWeb}")


    remarks = []

    # Normalize input
    extent = ExtentofRecognition.strip().lower()
    year_web = int(yearfromWeb) if yearfromWeb and str(yearfromWeb).isdigit() else None
    year_excel = int(yearfromexcel) if yearfromexcel and str(yearfromexcel).isdigit() else None

    # Case 1: Partial
    if extent == "partial":
        remarks.append("Standard is inconsistent.")
        if year_web is not None and year_excel is not None and year_web > year_excel:
            remarks.append(f"You need to update it to latest version ({yearfromWeb}).")

    # Case 2: Complete
    elif extent == "complete":
        if year_web is not None and year_excel is not None:
            if year_web > year_excel:
                remarks.append(f"You need to update it to latest version ({yearfromWeb}).")
            elif year_web == year_excel:
                remarks.append("You have updated version.")
        # if year_web is not None and year_excel is not None and year_web > year_excel:
        #     remarks.append(f"You need to update it to latest version ({yearfromWeb}).")

    # Case 3: not found
    elif extent == "not found":
        remarks.append("No data found in the website related to standard.")
    # Case 4: Any other Extent
    else:
        remarks.append("We encountered an issue while fetching data.")

    return " ".join(remarks)