from fastapi import FastAPI, BackgroundTasks
from icon_extractor import extract_icons_from_pdf
from index_chromadb import index_images
from Query_chromadb import main
import os

app = FastAPI()
 
def run_full_processing():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    pouch_file_path = os.path.join(current_dir, "RMC4916_0736003737_POUCH_LABEL.pdf")
    carton_file_path = os.path.join(current_dir, "RMC4916_0738002356_Carton_LABEL.pdf")
    extract_icons_from_pdf(pouch_file_path)
    extract_icons_from_pdf(carton_file_path)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    index_folder = os.path.join(current_dir, "Labelling_icons_by_pdf")
    # index_folder = r"C:\Users\kumar\Downloads\Image_comparison\Labelling_icons_by_pdf"
    index_images(index_folder)
    main()
    

@app.get("/")
async def root():
    return {"message": "Welcome to Symbol Extraction API"}
 
@app.get("/process-all/")
async def process_all(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_full_processing)
    return {"status": "Processing started in background"}