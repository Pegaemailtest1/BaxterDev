import openpyxl
import os
from openpyxl.styles import Border, Side
import logging
import sys
import ast
from collections import defaultdict, OrderedDict
from openpyxl.utils import column_index_from_string
from langchain.globals import set_llm_cache
from langchain_community.cache import InMemoryCache
from .questions_set3 import questions
from .retrieve_content_template import retrieve_collection_data_template
import re
import json
from typing import List, Dict
from .extract_standard_description import extract_description_for_standard
from .sota_updates import read_standards_from_sota_excel,update_sota_field,update_consistency_flags,update_remarks_based_on_sota

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

dict_data = defaultdict(list)

def extract_product_code(sheet):
    for row in sheet.iter_rows():
        for cell in row:
            if cell.value and isinstance(cell.value, str) and "product code" in cell.value.lower():
                adjacent_value = sheet.cell(row=cell.row, column=cell.column + 1).value
                return str(adjacent_value).strip() if adjacent_value else None
    return None

def extract_response_array(llama_response):
    try:
        # Try to parse the response directly as JSON (list of dictionaries)
        json_data = llama_response.strip()

        # If the response is wrapped in markdown backticks, extract the JSON inside it
        code_block = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", json_data, re.DOTALL)
        if code_block:
            json_data = code_block.group(1)

        # Attempt to load the JSON data into a Python object (list of dictionaries)
        parsed_data = json.loads(json_data)

        # Check if parsed_data is a list and contains dictionaries
        if isinstance(parsed_data, list) and all(isinstance(item, dict) for item in parsed_data):
            return parsed_data
        else:
            logging.warning(f"Unexpected format in LLaMA response: {parsed_data}")
            return []
    
    except Exception as e:
        logging.warning(f"Failed to extract array: {e}")
        return []

#find missing descriptions and add description into the merged_output
def find_missing_descriptions_and_add_descriptions(entries):
    for entry in entries:
        if not entry['description']:
            for key in ['Code_1', 'Code_2', 'Code_3', 'Code_4']:
                if entry[key] != 'N/A':
                    generate_text_file(f"find_missing_descriptions_and_add_descriptions.txt",entry[key])
                    print(f"{entry[key]}")
                    entry['description'] = extract_description_for_standard(entry[key])
                    print(f"standard: {entry[key]} - description: {entry['description']}")
                    break

def query_llama(question, document_id, prompt_template, full_document_search, where_filter, where_document, max_results, pipeline_config):
    
    llama_response = retrieve_collection_data_template(pipeline_config, question, document_id, prompt_template, full_document_search, where_filter, where_document, max_results)
    return extract_response_array(llama_response)


def extract_core_standard_number(code: str) -> str:
    """
    Extracts the core standard number in the format like '14971:2012' or '10993-1:2009'
    - Removes suffixes like '+A1:2015', '/AC:2018'
    - Matches in the order of:
        1. Full pattern with part and year (e.g. '10993-1:2018')
        2. Pattern with part only (e.g. '10993-1')
        3. Just the numeric code (e.g. '13485')
    """
    if not isinstance(code, str):
        return ""

    # Remove suffixes like +A1:2014, /AC:2009 etc.
    code = re.split(r'[\+\/]\s?A?C?\d*:\d{4}', code)[0]

    # Normalize spacing after colon
    code = re.sub(r':\s+', ':', code)

    # Priority match: '10993-1:2018' or '14971:2012'
    match = re.search(r'\b\d{4,5}(?:-\d+)?:\d{4}\b', code)
    if match:
        return match.group(0).strip()

    # Fallback: '10993-1'
    match = re.search(r'\b\d{4,5}-\d+\b', code)
    if match:
        return match.group(0).strip()

    # Fallback: '13485'
    match = re.search(r'\b\d{4,5}\b', code)
    if match:
        return match.group(0).strip()

    return code.strip()


def merge_iso_results_by_code(*document_results: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    Merges ISO results from multiple documents based on core standard code match.
    Each document gets a `Code_1`, `Code_2`, etc. column for each standard it contains.
    If a standard appears across multiple documents, it will be merged into the same row.
    """
    merged = defaultdict(lambda: defaultdict(list))  # Store full codes for each base code
    code_to_description = {}  # Store description for each base code

    # Step 1: Populate merged dictionary with full codes
    for idx, doc_data in enumerate(document_results):
        for item in doc_data:
            full_code = item.get("code", "").strip()
            base_code = extract_core_standard_number(full_code)

            if not base_code:
                continue

            # Store full code under the corresponding base code and document index (Code_1, Code_2, etc.)
            merged[base_code][f"Code_{idx+1}"].append(full_code)

            # Store the description for the first occurrence of the base code
            if base_code not in code_to_description:
                code_to_description[base_code] = item.get("description", "N/A")

    # Step 2: Prepare final output
    final_output = []
    all_code_keys = [f"Code_{i+1}" for i in range(len(document_results))]

    for base_code, code_values in merged.items():
        # Create a new row for each base code
        row = {
            "description": code_to_description.get(base_code, "N/A")
        }

        # Populate the row with the full codes for each document (Code_1, Code_2, ...)
        for code_key in all_code_keys:
            # If there are full codes for this key (document), use the first one, otherwise N/A
            row[code_key] = code_values.get(code_key, ["N/A"])[0]

        # Add this row to the final output
        final_output.append(row)

    return final_output

def remove_non_standards_data(input_data):
    output = []

    for item in input_data:
        # Extract all Code_X fields
        codes = [item.get(f"Code_{i}") for i in range(1, 5)]
        # Filter codes: skip "N/A" and must contain ':'
        valid_codes = [code for code in codes if code != "N/A" and ":" in code]
        
        if valid_codes:
            output.append(item)

    return output

def sota_check_and_conversion(merged_data, sota_file_path):

    filtered_data=remove_non_standards_data(merged_data)
    generate_text_file(f"filtered_data.txt",filtered_data)

    find_missing_descriptions_and_add_descriptions(filtered_data)
    logging.info(f"sota file: {sota_file_path}")
    sota_standards_list = read_standards_from_sota_excel(sota_file_path)
    generate_text_file(f"sota_standards_list.txt",sota_standards_list)
    new_columns = {
        "SOTA": "Standard not available in the SotA link",
        "CER": "",
        "ERC": "",
        "PRD": "",
        "Consistent": "",
        "Remarks":""
        }
        
    print(f"Added new columns to final output")
    
    for row in filtered_data:
        row.update(new_columns)

    updated_sota_output = update_sota_field(filtered_data, sota_standards_list)
    generate_text_file(f"updated_sota_output.txt",updated_sota_output)

    updated_consistency=update_consistency_flags(updated_sota_output)
    generate_text_file(f"updated_consistency.txt",updated_consistency)
    
    final_data_output = update_remarks_based_on_sota(updated_consistency)
    return final_data_output


def generate_set3_template(input_file_path, output_file_path, pipeline_config):

    sotaFile = f"{pipeline_config.get('sotafile_path', 'data')}/SOTA.xlsx"
    set_llm_cache(InMemoryCache())
    workbook = openpyxl.load_workbook(input_file_path)
    sheet = workbook.active

    product_code = extract_product_code(sheet)
    if not product_code:
        logging.warning("No product code found.")
        return

    document_outputs = []

    try:
        question_templates = questions()
        for q_template in question_templates["Questions"]:
            document_id = q_template["document_id"]
            question_text = q_template["question"].format(document_id=document_id, product_code=product_code)
            prompt_template = q_template["prompt_template"]
            full_document_search = q_template["full_document_search"]
            where_filter = q_template["where_filter"]
            q_max_results = q_template.get("max_results")
            where_document =q_template.get("where_document")
            #max_results_override = int(q_max_results) if q_max_results else MAX_RESULTS
            # logging.info(f"Processing question: {question_text} for document ID: {document_id}")
            response = query_llama(question_text, document_id, prompt_template, full_document_search,where_filter, where_document, q_max_results, pipeline_config)

            logging.info(f"Response for question '{question_text}': {response}")
            if isinstance(response, list):
                document_outputs.append(response)

    except Exception as e:
        logging.error(f"Error during LLaMA ISO query: {e}")
    
    logging.info(f"Document outputs: {document_outputs}")
    merged_data = merge_iso_results_by_code(*document_outputs)
    logging.info(f"Merged data: {merged_data}")
    generate_text_file(f"merged_data.txt",merged_data)

    final_data_output = sota_check_and_conversion(merged_data, sotaFile)
    
    logging.info(f"final_data_output: {final_data_output}")

    generate_text_file(f"final_data_output.txt",final_data_output)
    # Define the order of the fields (add Column1 first)
    columns = ["Column1"] + list(final_data_output[0].keys())
 
    # Start writing from row 13
    start_row = 12
 
    # Thin border for all sides
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
       
    for idx, row_data in enumerate(final_data_output, start=1):
        row_values = [idx]  # Column1 value
        row_values.extend(row_data[col] for col in columns[1:])
 
        for col_idx, value in enumerate(row_values, start=1):
            cell = sheet.cell(row=start_row + idx - 1, column=col_idx)
            cell.value = value
            cell.border = thin_border  # Apply border
 
    
    workbook.save(output_file_path)
    logging.info(f"Done! Output saved to: {output_file_path}")

def generate_text_file(fname,resultset):
    with open(fname, "w", encoding="utf-8") as f:
        f.write(f"{resultset}") 