import os
from openai import AzureOpenAI
from rag_pipeline.embeddings.base import EmbeddingBackend

class AzureOpenAIEmbedder(EmbeddingBackend):
    def __init__(self, model, base_url, api_key, deployment_name, model_version, api_type):
        self.model = model
        self.base_url = base_url
        self.api_key = api_key
        self.deployment_name = deployment_name
        self.model_version = model_version
        self.api_type = api_type

    def embed(self, text: str) -> list[float]:
        if not text.strip():
            return []
        try:
            client = AzureOpenAI(
                api_version=self.model_version,
                azure_endpoint=self.base_url,
                api_key=self.api_key,
            )

            # Call Azure OpenAI for embeddings (using `embeddings` endpoint)
            response = client.embeddings.create(
                input=[text],
                model=self.model
            )
            # Return the first embedding from the response
            return response.data[0].embedding
        except Exception as e:
            print(f"[AzureOpenAIEmbedder] Error generating embedding: {e}")
            return []

    def embed_section_chunks(self, chunks):
        embeddings = []
        valid_chunks = []
        for chunk in chunks:
            text = chunk.get("content", "")
            if not text.strip():
                continue
            embedding = self.embed(text)
            if embedding:
                embeddings.append(embedding)
                valid_chunks.append(chunk)
        return embeddings, valid_chunks