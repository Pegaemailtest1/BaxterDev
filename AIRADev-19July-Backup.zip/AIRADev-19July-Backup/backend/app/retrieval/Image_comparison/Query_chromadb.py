import pandas as pd
import os
import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel
import chromadb
from chromadb.config import Settings
import json


def connect_chromadb(CHROMA_HOST, CHROMA_PORT):
    chroma_client = chromadb.HttpClient(
        host=CHROMA_HOST,
        port=CHROMA_PORT,
        settings=Settings(anonymized_telemetry=False)
    )
    return chroma_client


def store_images_into_remote_chromadb():
    # --- Model & Processor ---
    device = "cpu"
    clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(device)
    clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

    # Connect to Remote ChromaDB
    CHROMA_HOST = "chromadb"  # Replace with your host, e.g., 'localhost'
    CHROMA_PORT = 8000  # Replace with your port
    client = connect_chromadb(CHROMA_HOST, CHROMA_PORT)
    collection = client.get_or_create_collection("image_embeddings")

    def embed_image(image_path):
        """Generate embeddings for an image using the CLIP model."""
        image = Image.open(image_path).convert("RGB")
        inputs = clip_processor(images=image, return_tensors="pt").to(device)
        with torch.no_grad():
            embedding = clip_model.get_image_features(**inputs)
        return embedding[0].cpu().tolist()

    def query_most_similar_per_label(query_embedding, label):
        """Query the most similar image in ChromaDB based on the label."""
        results = collection.get(where={"label": label}, include=["embeddings", "metadatas"])

        embeddings = results["embeddings"]
        metadatas = results["metadatas"]

        if embeddings is None or len(embeddings) == 0:
            return None

        embeddings_tensor = torch.tensor(embeddings).float()
        query_tensor = torch.tensor(query_embedding).unsqueeze(0).float()

        similarities = torch.nn.functional.cosine_similarity(query_tensor, embeddings_tensor)
        best_idx = torch.argmax(similarities).item()

        return {
            "label": label,
            "path": metadatas[best_idx]["path"],
            "similarity": similarities[best_idx].item()
        }

    def query_image(query_image_path):
        """Query images based on similarity to a given query image."""
        embedding = embed_image(query_image_path)
        labels = ["Pouch", "Carton"]
        results = []

        for label in labels:
            match = query_most_similar_per_label(embedding, label)
            if match:
                results.append(match)
        return results

    current_dir = os.path.dirname(os.path.abspath(__file__))
    # ---------- Read CSV and Apply Query ----------
    df_folder= os.path.join(current_dir, "Table/IFU_symbols_table.csv")
    df = pd.read_csv(df_folder)
    image_base_path = os.path.join(current_dir, "Table")
    

    def process_and_query(image_file):
        """Process and query each image from the CSV."""
        image_path = os.path.join(image_base_path, image_file)
        if not os.path.exists(image_path):
            return {"Pouch": "No", "Carton": "No"}

        results = query_image(image_path)

        pouch_status = "No"
        carton_status = "No"

        for res in results:
            if res['label'] == 'Pouch' and res['similarity'] >= 0.70:
                pouch_status = "Yes"
            if res['label'] == 'Carton' and res['similarity'] >= 0.70:
                carton_status = "Yes"

        return {"Pouch": pouch_status, "Carton": carton_status}

    df[['Pouch', 'Carton']] = df['image_file'].apply(process_and_query).apply(pd.Series)

    # ---------- Generate Required JSON Format ----------
    Answers = {
        "Warnings": [],
        "Claims": [],
        "Cautions": []
    }

    for _, row in df.iterrows():
        columns = []
        if row['Pouch'] == 'Yes':
            columns.append(6)
        if row['Carton'] == 'Yes':
            columns.append(8)

        item = {
            "value": row['description'],
            "column": columns
        }

        if row['type'] == 'Warnings':
            Answers['Warnings'].append(item)
        elif row['type'] == 'Claims':
            Answers['Claims'].append(item)
        elif row['type'] == 'Cautions':
            Answers['Cautions'].append(item)

    # ---------- Save to JSON ----------
    # with open('answers.json', 'w') as f:
    #     json.dump(Answers, f, indent=4)
    return json.dumps(Answers, indent=4)
    #print("answers.json has been created in the specified format.")


if __name__ == "__main__":
    result = store_images_into_remote_chromadb()
    print(result)
    
