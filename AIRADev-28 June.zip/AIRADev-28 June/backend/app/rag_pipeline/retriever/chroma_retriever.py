import chromadb
import json
from chromadb.config import Settings

def connect_chromadb(host, port):
    return chromadb.HttpClient(
        host=host,
        port=port,
        settings=Settings(anonymized_telemetry=False)
    )

def get_collection(client, name):
    return client.get_collection(name=name)

def retrieve_documents(collection, embedding, filter_values, where_filter, max_results, full_document_search):
    
    if full_document_search:
        if where_filter:
            where_filter = json.loads(where_filter)
            results = collection.get(
                include=["documents", "metadatas"],
                where=where_filter
            )
        else:
            results = collection.get(
            include=["documents", "metadatas"]
    )
    if where_filter:
        where = json.loads(where_filter)
        results = collection.query(
            query_embeddings=[embedding],
            n_results=max_results,
            include=["documents", "metadatas"],
            where=where
        )
    elif filter_values:
        results = collection.query(
            query_embeddings=[embedding],
            n_results=max_results,
            include=["documents", "metadatas"],
            where={"section": {"$in": filter_values}}
        )
    else:
        results = collection.query(
            query_embeddings=[embedding],
            n_results=max_results,
            include=["documents", "metadatas"]
        )
    
    return results