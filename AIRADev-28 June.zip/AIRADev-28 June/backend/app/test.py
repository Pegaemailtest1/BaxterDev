import os
from openai import AzureOpenAI
from PyPDF2 import PdfReader
import pdfplumber
 
endpoint = "https://aira-openai-dev.openai.azure.com/"
model_name = "gpt-4o"
deployment = "gpt-4o"
 
subscription_key = "EG1uazO0jiGj18BYA75kZu0WsYB690W0mHvBVUrefExzKCFudio6JQQJ99BFACYeBjFXJ3w3AAABACOG2skg"
api_version = "2024-12-01-preview"
 
client = AzureOpenAI(
    api_version=api_version,
    azure_endpoint=endpoint,
    api_key=subscription_key,
)
 
# Load PDF content
def extract_text_from_pdf(file_path):
    reader = PdfReader(file_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text.strip()
 
# Ask question to GPT with context
def ask_question(context, question):
    try:
        response = client.chat.completions.create(
            model=model_name,  # Azure-specific: use 'engine' instead of 'model'
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Use the context to answer questions."},
                {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"}
            ],
            temperature=0.1,
            max_tokens=1024,
            top_p=1.0,
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"[Error]: {e}"
 
def extract_pdf_text_and_tables(file_path):
    full_text = ""
    tables = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            full_text += page.extract_text() + "\n"
            page_tables = page.extract_tables()
            for table in page_tables:
                tables.append(table)
    return full_text, tables
 
 
def extract_pdf_tables(file_path):
    tables = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_tables = page.extract_tables()
            for table in page_tables:
                #tables.append(table)
                if table:  # Make sure table is not None
                    # Join columns with tab, rows with carriage return
                    # formatted_table = "\r".join([
                    #     "\t".join([str(cell) if cell is not None else "" for cell in row])
                    #     for row in table if row
                    # ])
                    tables.append(table)
    return tables
 
def generate_text_file(filename, question, answer):
    with open(filename, "a", encoding="utf-8") as f:  # 'a' = append mode
        f.write("----------------------------\n")
        f.write(f"Q: {question}\n")
        f.write(f"A: {answer}\n\n")
 
def main():
    pdf_path = "sample2.pdf"  # Replace with your filename
    print("🔍 Loading PDF content...")
    context = extract_pdf_tables(pdf_path)
    print(f"context: {context}")
    if not context:
        print("❌ Failed to read content from the PDF.")
        return
 
    print("✅ PDF loaded. You can now ask questions. Type 'exit' to quit.\n")
 
    answer = ask_question(context, prompt)
    generate_text_file("azure_answers.txt",prompt,answer)
    print(f"\n💡 Answer:\n{answer}\n")
 
    # while True:
    #     question = input("❓ Your question: ").strip()
    #     print(f"Question: {question}")
    #     if question.lower() in ["exit", "quit"]:
    #         print("👋 Exiting application.")
    #         break
    #     answer = ask_question(context, question)
    #     generate_text_file("azure_answers.txt",question,answer)
    #     print(f"\n💡 Answer:\n{answer}\n")
 
prompt="""
Extract all occurrences of the following standards from the document :
 
* ISO
* ES ISO
* BS EN
* EN
* BS EN ISO
 
Return the results in the following JSON format:
 
```json
rows:[
  {
    "code": "<standard_code>",
    "description": "<standard_description>"
  },
  ...
]
```
 
**Example Output:**
 
```json
rows:[
  {
    "code": "ISO 11228-1:2003",
    "description": "Ergonomics - Manual handling"
  },
  ...
]
```
 
If a description is not available for a particular standard, leave the `description` field as an empty string.
standard should have colon(:) and it ends with a year
if you find any duplicate standards then remove one entry with empty description
"""
 
prompt2="""
Extract all occurrences of the following standards from the document:
 
* ISO
* ES ISO
* BS EN
* EN
* BS EN ISO
 
Return the results in the following JSON format:
 
```json
[
  {
    "code": "<standard_code>",
    "description": "<standard_description>"
  },
  ...
]
```
 
**Example Output:**
 
```json
[
  {
    "code": "ISO 11228-1:2003",
    "description": "Ergonomics - Manual handling"
  },
  ...
]
```
 
If a description is not available for a particular standard, leave the `description` field as an empty string.
standard should have colon(:) and it ends with a year.
if you find any duplicate standards then remove one entry with empty description
"""
 
if __name__ == "__main__":
    main()