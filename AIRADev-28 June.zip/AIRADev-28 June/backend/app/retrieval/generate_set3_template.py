import openpyxl
import logging
import sys
import ast
from collections import defaultdict, OrderedDict
from openpyxl.utils import column_index_from_string
from langchain.globals import set_llm_cache
from langchain_community.cache import InMemoryCache
from .questions_set3 import questions
from .retrieve_content_template import retrieve_collection_data_template
import re
import json
from typing import List, Dict


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

dict_data = defaultdict(list)

def extract_product_code(sheet):
    for row in sheet.iter_rows():
        for cell in row:
            if cell.value and isinstance(cell.value, str) and "product code" in cell.value.lower():
                adjacent_value = sheet.cell(row=cell.row, column=cell.column + 1).value
                return str(adjacent_value).strip() if adjacent_value else None
    return None

def extract_response_array(llama_response):
    try:
        # Extract content between triple backticks, fallback to entire string
        code_block = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", llama_response, re.DOTALL)
        json_data = code_block.group(1) if code_block else llama_response.strip()

        # Attempt to load JSON
        return json.loads(json_data)
    except Exception as e:
        logging.warning(f"Failed to extract array: {e}")
        return []

def query_llama(question, document_id, prompt_template, full_document_search, where_filter,
                pipeline_config):
    llama_response = retrieve_collection_data_template(pipeline_config, question, document_id, prompt_template, full_document_search, where_filter)
    return extract_response_array(llama_response)


def extract_core_standard_number(code: str) -> str:
    """
    Extracts the core standard number in the format like '14971:2012' or '10993-1:2009'
    - Removes suffixes like '+A1:2015', '/AC:2018'
    - Matches in the order of:
        1. Full pattern with part and year (e.g. '10993-1:2018')
        2. Pattern with part only (e.g. '10993-1')
        3. Just the numeric code (e.g. '13485')
    """
    if not isinstance(code, str):
        return ""

    # Remove suffixes like +A1:2014, /AC:2009 etc.
    code = re.split(r'[\+\/]\s?A?C?\d*:\d{4}', code)[0]

    # Normalize spacing after colon
    code = re.sub(r':\s+', ':', code)

    # Priority match: '10993-1:2018' or '14971:2012'
    match = re.search(r'\b\d{4,5}(?:-\d+)?:\d{4}\b', code)
    if match:
        return match.group(0).strip()

    # Fallback: '10993-1'
    match = re.search(r'\b\d{4,5}-\d+\b', code)
    if match:
        return match.group(0).strip()

    # Fallback: '13485'
    match = re.search(r'\b\d{4,5}\b', code)
    if match:
        return match.group(0).strip()

    return code.strip()


def merge_iso_results_by_code(*document_results: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    Merges ISO results from multiple documents based on core standard code match.
    Example:
    - "BS EN ISO 14971:2012+A1:2014" and "ISO 14971:2012+A1:2015" → matched as "14971:2012"
    - Output format:
        [
            {
                "description": "Some description",
                "Code_1": "BS EN ISO 14971:2012+A1:2014",
                "Code_2": "ISO 14971:2012+A1:2015",
                ...
            },
            ...
        ]
    """
    merged = defaultdict(dict)
    all_code_keys = [f"Code_{i+1}" for i in range(len(document_results))]
    code_to_description = {}

    for idx, doc_data in enumerate(document_results):
        code_key = f"Code_{idx+1}"
        for item in doc_data:
            full_code = item.get("code", "").strip()
            base_code = extract_core_standard_number(full_code)

            if not base_code:
                continue

            merged[base_code][code_key] = full_code

            # Only store the first available description per base code
            if base_code not in code_to_description:
                code_to_description[base_code] = item.get("description", "")

    final_output = []
    for base_code, code_values in merged.items():
        row = {
            "description": code_to_description.get(base_code, "N/A")
        }
        for key in all_code_keys:
            row[key] = code_values.get(key, "N/A")
        final_output.append(row)

    return final_output


def generate_set3_template(input_file_path, output_file_path, pipeline_config):

    set_llm_cache(InMemoryCache())
    workbook = openpyxl.load_workbook(input_file_path)
    sheet = workbook.active

    product_code = extract_product_code(sheet)
    if not product_code:
        logging.warning("No product code found.")
        return

    document_outputs = []

    try:
        question_templates = questions()
        for q_template in question_templates["Questions"]:
            question_text = q_template["question"].format(product_code=product_code)
            document_id = q_template["document_id"]
            prompt_template = q_template["prompt_template"]
            full_document_search = q_template["full_document_search"]
            where_filter = q_template["where_filter"]
            q_max_results = q_template.get("max_results")
            #max_results_override = int(q_max_results) if q_max_results else MAX_RESULTS
            # logging.info(f"Processing question: {question_text} for document ID: {document_id}")
            response = query_llama(
                question_text, document_id, prompt_template, full_document_search,
                where_filter, pipeline_config
            )

            logging.info(f"Response for question '{question_text}': {response}")
            if isinstance(response, list):
                document_outputs.append(response)

    except Exception as e:
        logging.error(f"Error during LLaMA ISO query: {e}")

    logging.info(f"Document outputs: {document_outputs}")
    merged_data = merge_iso_results_by_code(*document_outputs)
    logging.info(f"Merged data: {merged_data}")

    output_start_row = 12
    for i, row_data in enumerate(merged_data):
        sheet.cell(row=output_start_row + i, column=2).value = row_data["description"]
        sheet.cell(row=output_start_row + i, column=3).value = row_data.get("Code_1", "N/A")
        sheet.cell(row=output_start_row + i, column=4).value = row_data.get("Code_2", "N/A")
        sheet.cell(row=output_start_row + i, column=5).value = row_data.get("Code_3", "N/A")
        sheet.cell(row=output_start_row + i, column=6).value = row_data.get("Code_4", "N/A")

    workbook.save(output_file_path)
    logging.info(f"Done! Output saved to: {output_file_path}")
