import chromadb
import requests
from chromadb.config import Settings
import logging
import sys
import json
from .generate_prompt import select_prompt_template
from .extract_components import extract_components

import base64
import re
from PIL import Image, ImageDraw
from io import BytesIO
import pytesseract
import os
from openai import AzureOpenAI
from utils import load_constants

# Load constants from config
config = load_constants()

# Azure OpenAI configuration
Azure_FM_MODEL = config["llms"]["azure"]["model"]
Azure_Model = config["llms"]["azure"]["model"]
Azure_base_url = config["llms"]["azure"]["base_url"]
Azure_api_type = config["llms"]["azure"]["api_type"]
Azure_api_key = config["llms"]["azure"]["api_key"]
Azure_api_version = config["llms"]["azure"]["api_version"]
Azure_azure_deployment_name = config["llms"]["azure"]["azure_deployment_name"]


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

def connect_chromadb(CHROMA_HOST, CHROMA_PORT):
    chroma_client = chromadb.HttpClient(
        host=CHROMA_HOST,
        port=CHROMA_PORT,
        settings=Settings(anonymized_telemetry=False)
    )
    return chroma_client

def get_chromadb_collection(chroma_client, collection_name):
    return chroma_client.get_collection(name=collection_name)

# Embed with Azure OpenAI
def embed_with_azure(query):
    # Setup for the Azure OpenAI client
    api_key = "EG1uazO0jiGj18BYA75kZu0WsYB690W0mHvBVUrefExzKCFudio6JQQJ99BFACYeBjFXJ3w3AAABACOG2skg"
    api_base = "https://aira-openai-dev.openai.azure.com/"
    api_version = "2023-05-15"
    model = "text-embedding-3-large"

    try:
        client = AzureOpenAI(
            api_version=api_version,
            azure_endpoint=api_base,
            api_key=api_key,
        )
    # Call the Azure OpenAI API for embeddings
        response = client.embeddings.create(
                input=[query],
                model=model
            )
        # Return the first embedding from the response
        return response.data[0].embedding
    except Exception as e:
        print(f"[AzureOpenAIEmbedding] Error generating embedding: {e}")
        return []

def ask_azure_fm_model(context, prompt, query_text, deployment_name, temperature, max_tokens):
    api_key = "EG1uazO0jiGj18BYA75kZu0WsYB690W0mHvBVUrefExzKCFudio6JQQJ99BFACYeBjFXJ3w3AAABACOG2skg"
    api_base = "https://aira-openai-dev.openai.azure.com/"
    api_version = "2025-01-01-preview"
    model = "gpt-4o"

    try:
        fm_client = AzureOpenAI(
            api_version=api_version,
            azure_endpoint=api_base,
            api_key=api_key,
        )
        # Azure OpenAI ChatCompletion API call
        response = fm_client.chat.completions.create(
            model=model,  # Azure-specific: use 'engine' instead of 'model'
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Use the context to answer questions."},
                {"role": "user", "content": f"prompt:\n{prompt}\n\nQuestion: {query_text}"}
            ],
            temperature=0.1,
            max_tokens=1024,
            top_p=1.0,
        )
        print(f"Azure Connections: {fm_client}")
        return response.choices[0].message.content
    except Exception as e:
        return f"[Error]: {e}"
    

def retrieve_collection_data(CHROMA_HOST, CHROMA_PORT, COLLECTION_NAME, EMBED_MODEL, query_text, max_results, FM_MODEL, OLLAMA_URL, temperature, max_tokens):
    client = connect_chromadb(CHROMA_HOST, CHROMA_PORT)
    collection = get_chromadb_collection(client, COLLECTION_NAME)

    extracted_components = extract_components(query_text)
    collection_filter = extracted_components.get("section")
    question = extracted_components.get("question")
    field = extracted_components.get("field")
    logging.info(f"field: {field}")
    question_text = question + "." if question else query_text
    logging.info(f"question_text: {question_text}")
    # Use Azure OpenAI for embedding
    query_embedding = embed_with_azure(question_text)
    logging.error(f"query_embedding:{query_embedding}")

    filter_values = collection_filter if isinstance(collection_filter, list) else [collection_filter] if collection_filter else None
    target_doc_id = extracted_components.get("document_id")
    logging.info(f"Target document id: {target_doc_id}")

    # Filter by section if provided
    meta_filter = {}
    if field:
        meta_filter["section"] = {"$contains": field}
    if target_doc_id:
        meta_filter["source"] = {"$contains": target_doc_id}

    full_document_search = ""
    document_id = "RMC4916_0719004306_IFU_LABEL"
    #where_filter = "{\"$and\": [{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}, {\"type\": {\"$eq\": \"section\"}}]}"
    #where_filter = ""
    #where_filter = "{\"document_id\": {\"$eq\": \"BXU535425 Rev D_User Needs\"}}"
    # Step 1: Get using one filter (e.g., by source)
    results = collection.get(
            include=["documents", "metadatas"]
    )


    # Step 2: Apply additional filtering (e.g., exclude a specific section)
    # filtered_docs = []
    # for doc, meta in zip(results["documents"], results["metadatas"]):
    #     if meta.get("section") != "Colour Reference:":
    #         filtered_docs.append((doc, meta))
    #logging.info(f"Results: {results}")
    documents = results.get("documents", [[]])
    metadatas = results.get("metadatas", [[]])


    logging.info(f"documents:{documents}")
    # logging.info(f"metadatas:{metadatas}")
    

    # Step 6: Filter based on metadata match
    # filtered_chunks = []
    filtered_docs = documents

    logging.info(f"Filtered chunks: {filtered_docs}")
    # Step 7: Combine into final context
    context = "\n\n".join(
        str(chunk).strip() for chunk in filtered_docs if str(chunk).strip()
    )

    
    #logging.info(f"Filtered Query results: {filtered_chunks}")
    #logging.info(f"context: {context}")

    prompt = select_prompt_template(context, query_text)

    logging.info(f"Generated prompt: {prompt}")

    # Get response from Azure FM model
    azure_response = ask_azure_fm_model(context, prompt, query_text, FM_MODEL, temperature, max_tokens)
    return azure_response

