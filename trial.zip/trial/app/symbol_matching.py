import os
import json
import torch
import torchvision.transforms as transforms
from torchvision import models
from PIL import Image
from tqdm import tqdm
from sklearn.metrics.pairwise import cosine_similarity
def main_matching():
    # Settings
    ICONS_FOLDER = "icons_by_page"
    VECTOR_JSON_PATH = os.path.join("vector_symbols", "vector_symbols.json")
    SIMILARITY_THRESHOLD = 0.85  # Lowered to increase match count
    RESULT_FILE = "matched_results.json"
    DESCRIPTIONS_TXT_FILE = "unique_descriptions.txt"
    RETURN_MULTIPLE_MATCHES = True
   
    # Load pretrained model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
    model = torch.nn.Sequential(*list(model.children())[:-1])  # Remove classification layer
    model.eval()
    model.to(device)
   
    # Transform
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                            std=[0.229, 0.224, 0.225])
    ])
   
    def extract_features(image_path):
        try:
            image = Image.open(image_path).convert("RGB")
            img_t = transform(image).unsqueeze(0).to(device)
            with torch.no_grad():
                features = model(img_t).squeeze().cpu().numpy()
            return features.reshape(1, -1)
        except Exception as e:
            print(f"Error processing {image_path}: {e}")
            return None
   
    # Load vector symbols from JSON
    print("🔍 Loading vector symbol features from JSON...")
   
    with open(VECTOR_JSON_PATH, "r", encoding="utf-8") as f:
        vector_data = json.load(f)
   
    vector_features = []
    for entry in vector_data:
        desc = entry.get("description", "").strip()
        rel_img_path = entry.get("image_file", "")
        if not desc or not rel_img_path:
            continue
        full_img_path = os.path.join("vector_symbols", rel_img_path)
        if not os.path.exists(full_img_path):
            continue
        feat = extract_features(full_img_path)
        if feat is not None:
            vector_features.append({
                "path": full_img_path,
                "features": feat,
                "description": desc
            })
   
    print(f"✅ {len(vector_features)} valid vector symbols loaded.\n")
   
    # Compare with icons
    matches = []
    print("🔁 Comparing icons to vector symbols...")
   
    for subfolder in os.listdir(ICONS_FOLDER):
        subfolder_path = os.path.join(ICONS_FOLDER, subfolder)
        if not os.path.isdir(subfolder_path):
            continue
   
        icon_files = [f for f in os.listdir(subfolder_path) if f.lower().endswith(".png")]
   
        for icon_file in tqdm(icon_files, desc=f"Processing {subfolder}"):
            icon_path = os.path.join(subfolder_path, icon_file)
            icon_feat = extract_features(icon_path)
            if icon_feat is None:
                continue
   
            sims = [(cosine_similarity(icon_feat, v["features"])[0][0], v) for v in vector_features]
            sims = [s for s in sims if s[0] >= SIMILARITY_THRESHOLD]
   
            if RETURN_MULTIPLE_MATCHES:
                for sim_score, match in sims:
                    matches.append({
                        "icon_file": os.path.relpath(icon_path),
                        "matched_symbol_file": os.path.relpath(match["path"]),
                        "description": match["description"].strip(),
                        "similarity": float(sim_score)
                    })
            else:
                if sims:
                    sims.sort(key=lambda x: x[0], reverse=True)
                    top_sim, best_match = sims[0]
                    matches.append({
                        "icon_file": os.path.relpath(icon_path),
                        "matched_symbol_file": os.path.relpath(best_match["path"]),
                        "description": best_match["description"].strip(),
                        "similarity": float(top_sim)
                    })
   
    # Save results to JSON
    with open(RESULT_FILE, "w", encoding="utf-8") as f:
        json.dump(matches, f, indent=4)
   
    # Save cleaned, unique descriptions to TXT
    unique_descriptions = set()
    for match in matches:
        desc = match["description"].strip().lower()  # Normalized
        if desc:
            unique_descriptions.add(desc)
   
    with open(DESCRIPTIONS_TXT_FILE, "w", encoding="utf-8") as f:
        for desc in sorted(unique_descriptions):
            f.write(desc + "\n")
   
    # Done
    print(f"\n✅ {len(matches)} matches found.")
    print(f"📁 Results saved to: {RESULT_FILE}")
    print(f"📝 Unique descriptions saved to: {DESCRIPTIONS_TXT_FILE}")
if __name__ == "__main__":
    main_matching()